# WKWebViewSimpleDemo
iOS8中WebKit库中的WKWebView简单使用方法，包括初始化，最基础的代理方法，以及JS加载。
技术支持网站：http://www.brighttj.com/ios/ios-wkwebview-new-features-and-use.html
