//
//  AppDelegate.m
//  slowdun3
//
//  Created by Jymn_Chen on 2018/3/19.
//  Copyright © 2018年 com.slowdun3. All rights reserved.
//

#import "AppDelegate.h"

// managers
#import "SDConfigManager.h"
#import "SDIndustriesManager.h"
#import "SDStockManager.h"

// utils
#import "SDFileUtil.h"
#import "HGCFileManager.h"

// tests
#import "SDModelsTest.h"

@interface AppDelegate ()

@property (weak) IBOutlet NSWindow *window;

@end

@implementation AppDelegate

- (void)applicationDidFinishLaunching:(NSNotification *)aNotification {
    // 先初始化配置
    [SDConfigManager sharedInstance];
    [SDIndustriesManager sharedInstance];
    
//    [mSDStockManager setup_industry_vintage_sprit];
    
//    NSString *filePath = [[mHGCFileManager documentsPath] stringByAppendingPathComponent:@"test.html"];
}

- (void)applicationWillTerminate:(NSNotification *)aNotification {
    // Insert code here to tear down your application
}

- (void)doUnitTests {
    SDModelsTest *test = [SDModelsTest new];
    [test start];
}

@end
