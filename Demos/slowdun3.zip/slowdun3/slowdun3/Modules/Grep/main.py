#!/usr/bin/env python
# -*- coding: utf-8 -*-

import sys
import time
from managers.st_mgr import StMgr

if __name__ == "__main__":
	reload(sys)
	sys.setdefaultencoding('utf8')
	starttime = time.time()

	st_mgr = StMgr()

	draw_all = False
	
	# 家电行业
	# st_mgr.fetch_eletric_all_data_from_network(cur_data_only=False)

	# 家电的厨电细分行业
	# st_mgr.fetch_eletric_kitchen_data_from_network(cur_data_only=False)

	# 酿酒的白酒细分行业
	# st_mgr.fetch_vintage_spirit_data_from_network(cur_data_only=False)

	# 食品饮料的调味品细分行业
	# st_mgr.fetch_fooddrink_condiment_data_from_network(cur_data_only=False)

	# 房地产行业
	# st_mgr.fetch_realestate_all_data_from_network(cur_data_only=False)

	# 房地产的 PPP 细分行业
	# st_mgr.fetch_realestate_ppp_data_from_network(cur_data_only=False)

	# 中药行业
	# st_mgr.fetch_cn_medicine_all_from_network(cur_data_only=False)

	# 机场行业
	# st_mgr.fetch_airport_all_from_network(cur_data_only=False)

	# 造纸行业
	# st_mgr.fetch_paper_data_from_network(cur_data_only=False)

	# 其它
	# st_mgr.fetch_others_data_from_network(cur_data_only=False)

	# # ST
	# st_mgr.fetch_ST_data_from_network(cur_data_only=False)
 
 	endtime = time.time()
 	duration = endtime - starttime
 	print "耗时: %s 秒" % duration
