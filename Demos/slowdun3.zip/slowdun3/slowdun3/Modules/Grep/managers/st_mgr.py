# -*- coding: utf-8 -*-

import os
import sys
import re
from utils.util_req import ReqUtil
from utils.util_re import RegUtil
from utils.util_file import FileUtil
import utils.util_cons as Cons
import json

class StMgr(object):
	def __init__(self):
		self.load_global_config()

	def load_global_config(self):
		dpath = '../Config'
		fu = FileUtil(basedir=dpath)
		fpath = 'global.json'
		if fu.is_file_exists(fpath):
			json_data = json.loads(fu.read_from_file(fpath=fpath))
        else:
            json_data = None
		assert json_data is not None
		self.year_from = json_data['yearFrom']
		self.year_to = json_data['yearTo']

	def fetch_data_from_network(self, industry, st_symbol, cur_data_only=False):
		if not industry or len(industry) == 0:
			industry = Cons.INDUSTRY_UNKNOWN
		assert st_symbol and len(st_symbol) > 0

		# 创建目录
		dbpath = '../../DataSource'
		fu = FileUtil(basedir=None)
		fu.create_dir(dpath=dbpath, force=False)
		fu.cd(dpath=dbpath)
		fu.create_dir(dpath=industry, force=False)
		fu.cd(dpath=industry)

		# 匹配股票名
		req = ReqUtil(st_symbol)
		html_content = req.prepare()
		if html_content is not None:
			desc = '<title>(.*?) '
			# print desc
			st_name = RegUtil.match_one_from_re(desc, html_content)
		else:
			st_name = '匹配失败'
		dirname = '%s_%s' % (st_symbol, st_name)
		fu.create_dir(dpath=dirname, force=False)
		fu.cd(dpath=dirname)

		# 保存 html 内容
		# fpath = '%s_mainpage.html' % st_name
		# fu.write_to_file(fpath=fpath, content=html_content)

		# 最新数据
		content = req.fetch(
			ReqUtil.REP_TYPE_CUR,
			year_from=self.year_from,
			year_to=self.year_to)
		# print content
		# json_data = json.loads(content)
		fpath = '%s_quote.json' % dirname
		fu.write_to_file(fpath=fpath, content=content)
		if cur_data_only:
			return

		# 资产负债表
		content = req.fetch(
			report_type=ReqUtil.REP_TYPE_ASSETS,
			year_from=self.year_from,
			year_to=self.year_to)
		# print content
		# json_data = json.loads(content)
		fpath = '%s_zcfzb.json' % dirname
		fu.write_to_file(fpath=fpath, content=content)
		
		# 利润表
		content = req.fetch(
			ReqUtil.REP_TYPE_PROFIT,
			year_from=self.year_from,
			year_to=self.year_to)
		# print content
		# json_data = json.loads(content)
		fpath = '%s_gslrb.json' % dirname
		fu.write_to_file(fpath=fpath, content=content)
		
		# 现金流量表
		content = req.fetch(
			ReqUtil.REP_TYPE_CASH,
			year_from=self.year_from,
			year_to=self.year_to)
		# print content
		# json_data = json.loads(content)
		fpath = '%s_xjllb.json' % dirname
		fu.write_to_file(fpath=fpath, content=content)

		# 分红送配
		content = req.fetch(
			ReqUtil.REP_TYPE_BONUS,
			year_from=self.year_from,
			year_to=self.year_to)
		# print content
		# json_data = json.loads(content)
		fpath = '%s_bonus.json' % dirname
		fu.write_to_file(fpath=fpath, content=content)

	def fetch_industry_data_from_network(self, industry, cur_data_only=False):
		dpath = '../Config'
		fu = FileUtil(basedir=dpath)
		fpath = '%s_stocks.json' % industry
		if fu.is_file_exists(fpath):
			json_data = json.loads(fu.read_from_file(fpath=fpath))
		else:
			json_data = None
		assert json_data is not None
		for conf in json_data:
			st_symbol = conf['symbol']
			self.fetch_data_from_network(industry=industry, st_symbol=st_symbol, cur_data_only=cur_data_only)

	# 家电行业
	def fetch_eletric_all_data_from_network(self, cur_data_only=False):
		self.fetch_industry_data_from_network(
			industry=Cons.INDUSTRY_ELETRIC_ALL, 
			cur_data_only=cur_data_only)

	# 家电的厨电细分行业
	def fetch_eletric_kitchen_data_from_network(self, cur_data_only=False):
		self.fetch_industry_data_from_network(
			industry=Cons.INDUSTRY_ELETRIC_KITCHEN, 
			cur_data_only=cur_data_only)

	# 酿酒的白酒细分行业
	def fetch_vintage_spirit_data_from_network(self, cur_data_only=False):
		self.fetch_industry_data_from_network(
			industry=Cons.INDUSTRY_VINTAGE_SPIRIT, 
			cur_data_only=cur_data_only)

	# 食品饮料的调味品细分行业
	def fetch_fooddrink_condiment_data_from_network(self, cur_data_only=False):
		self.fetch_industry_data_from_network(
			industry=Cons.INDUSTRY_FOODDRINK_CONDIMENT, 
			cur_data_only=cur_data_only)

	# 房地产行业
	def fetch_realestate_all_data_from_network(self, cur_data_only=False):
		self.fetch_industry_data_from_network(
			industry=Cons.INDUSTRY_REALESTATE_ALL, 
			cur_data_only=cur_data_only)

	# 房地产的 PPP 细分行业
	def fetch_realestate_ppp_data_from_network(self, cur_data_only=False):
		self.fetch_industry_data_from_network(
			industry=Cons.INDUSTRY_REALESTATE_PPP, 
			cur_data_only=cur_data_only)
		
	# 中药行业
	def fetch_cn_medicine_all_from_network(self, cur_data_only=False):
		self.fetch_industry_data_from_network(
			industry=Cons.INDUSTRY_CN_MEDICINE_ALL, 
			cur_data_only=cur_data_only)
		
    # 机场行业
	def fetch_airport_all_from_network(self, cur_data_only=False):
		self.fetch_industry_data_from_network(
			industry=Cons.INDUSTRY_AIRPORT_ALL, 
			cur_data_only=cur_data_only)
		
	# 未分类
	def fetch_others_data_from_network(self, cur_data_only=False):
		self.fetch_industry_data_from_network(
			industry=Cons.INDUSTRY_UNKNOWN, 
			cur_data_only=cur_data_only)
		
	# ST
	def fetch_ST_data_from_network(self, cur_data_only=False):
		self.fetch_industry_data_from_network(
			industry=Cons.INDUSTRY_ST_ALL, 
			cur_data_only=cur_data_only)
		
	# 造纸行业
	def fetch_paper_data_from_network(self, cur_data_only=False):
		self.fetch_industry_data_from_network(
			industry=Cons.INDUSTRY_PAPER_ALL, 
			cur_data_only=cur_data_only)
