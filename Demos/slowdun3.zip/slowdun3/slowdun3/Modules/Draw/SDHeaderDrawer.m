//
//  SDHeaderDrawer.m
//  slowdun3
//
//  Created by Jymn_Chen on 2018/3/25.
//  Copyright © 2018年 com.slowdun3. All rights reserved.
//

#import "SDHeaderDrawer.h"

@interface SDHeaderDrawer ()

SD_PROPERTY_ASSIGN SDHeaderStyle style;
SD_PROPERTY_COPY_STR content;

@end

@implementation SDHeaderDrawer

#pragma mark - Init

- (instancetype)initWithStyle:(SDHeaderStyle)style content:(NSString *)content {
    self = [super init];
    if (self) {
        _style = style;
        _content = content;
    }
    return self;
}

#pragma mark - Override Methods

- (NSString *)draw {
    switch (_style) {
        case SDHeaderStyle_Title1: {
            return [NSString stringWithFormat:@"<h1>%@</h1>", _content];
        }
        case SDHeaderStyle_Title2: {
            return [NSString stringWithFormat:@"<h2>%@</h2>", _content];
        }
        case SDHeaderStyle_Title3: {
            return [NSString stringWithFormat:@"<h3>%@</h3>", _content];
        }
        case SDHeaderStyle_Title4: {
            return [NSString stringWithFormat:@"<h4>%@</h4>", _content];
        }
        case SDHeaderStyle_Line: {
            return @"<hr/>";
        }
    }
    return [super draw];
}

@end
