//
//  SDHeaderDrawer.h
//  slowdun3
//
//  Created by Jymn_Chen on 2018/3/25.
//  Copyright © 2018年 com.slowdun3. All rights reserved.
//
//  画标题，分割线等

#import "SDBaseDrawer.h"

typedef NS_ENUM(uint32_t, SDHeaderStyle) {
    SDHeaderStyle_Title1 = 0,
    SDHeaderStyle_Title2,
    SDHeaderStyle_Title3,
    SDHeaderStyle_Title4,
    SDHeaderStyle_Line,
};

@interface SDHeaderDrawer : SDBaseDrawer

- (instancetype)initWithStyle:(SDHeaderStyle)style content:(NSString *)content;

@end
