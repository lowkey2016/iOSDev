//
//  SDBaseDrawer.h
//  slowdun3
//
//  Created by Jymn_Chen on 2018/3/25.
//  Copyright © 2018年 com.slowdun3. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "SDCommon.h"

@interface SDBaseDrawer : NSObject

- (NSString *)draw;

@end
