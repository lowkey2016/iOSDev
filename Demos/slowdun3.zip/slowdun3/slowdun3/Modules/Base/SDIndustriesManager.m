//
//  SDIndustriesManager.m
//  slowdun3
//
//  Created by Jymn_Chen on 2018/3/20.
//  Copyright © 2018年 com.slowdun3. All rights reserved.
//

#import "SDIndustriesManager.h"

@interface SDIndustriesManager ()

@property (nonatomic, readwrite, strong) SDIndustryModel *industry_unknown; // 未分类
@property (nonatomic, readwrite, strong) SDIndustryModel *industry_eletric_all; // 家电行业
@property (nonatomic, readwrite, strong) SDIndustryModel *industry_eletric_kitchen; // 厨电行业
@property (nonatomic, readwrite, strong) SDIndustryModel *industry_vintage_sprit; // 白酒行业
@property (nonatomic, readwrite, strong) SDIndustryModel *industry_fooddrink_condiment; // 调味品行业
@property (nonatomic, readwrite, strong) SDIndustryModel *industry_realestate_all; // 房地产行业
@property (nonatomic, readwrite, strong) SDIndustryModel *industry_realestate_ppp; // PPP房地产行业
@property (nonatomic, readwrite, strong) SDIndustryModel *industry_cn_medicine_all; // 中药行业
@property (nonatomic, readwrite, strong) SDIndustryModel *industry_airport_all; // 机场行业
@property (nonatomic, readwrite, strong) SDIndustryModel *industry_st_all; // ST
@property (nonatomic, readwrite, strong) SDIndustryModel *industry_paper_all; // 造纸行业

@end

@implementation SDIndustriesManager

#pragma mark - Singleton

+ (instancetype)sharedInstance {
    static id _sharedInstance = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        _sharedInstance = [[super allocWithZone:NULL] init];
    });
    return _sharedInstance;
}

+ (instancetype)allocWithZone:(struct _NSZone *)zone {
    return [[self class] sharedInstance];
}

//- (instancetype)copyWithZone:(NSZone *)zone {
//    return [[self class] sharedInstance];
//}
//
//- (instancetype)mutableCopyWithZone:(NSZone *)zone {
//    return [[self class] sharedInstance];
//}

#pragma mark - Init

- (instancetype)init {
    self = [super init];
    if (self) {
        [self setup];
    }
    return self;
}

- (void)setup {
    self.industry_unknown = [[SDIndustryModel alloc] initWithName:@"未分类" isFin:NO];
    self.industry_eletric_all = [[SDIndustryModel alloc] initWithName:@"家电行业" isFin:NO];
    self.industry_eletric_kitchen = [[SDIndustryModel alloc] initWithName:@"厨电行业" isFin:NO];
    self.industry_vintage_sprit = [[SDIndustryModel alloc] initWithName:@"白酒行业" isFin:NO];
    self.industry_fooddrink_condiment = [[SDIndustryModel alloc] initWithName:@"调味品行业" isFin:NO];
    self.industry_realestate_all = [[SDIndustryModel alloc] initWithName:@"房地产行业" isFin:NO];
    self.industry_realestate_ppp = [[SDIndustryModel alloc] initWithName:@"PPP房地产行业" isFin:NO];
    self.industry_cn_medicine_all = [[SDIndustryModel alloc] initWithName:@"中药行业" isFin:NO];
    self.industry_airport_all = [[SDIndustryModel alloc] initWithName:@"机场行业" isFin:NO];
    self.industry_st_all = [[SDIndustryModel alloc] initWithName:@"ST" isFin:NO];
    self.industry_paper_all = [[SDIndustryModel alloc] initWithName:@"造纸行业" isFin:NO];
}

@end
