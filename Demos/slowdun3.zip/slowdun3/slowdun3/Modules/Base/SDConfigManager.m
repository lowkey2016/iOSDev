//
//  SDConfigManager.m
//  slowdun3
//
//  Created by Jymn_Chen on 2018/3/25.
//  Copyright © 2018年 com.slowdun3. All rights reserved.
//

#import "SDConfigManager.h"
#import "SDFileUtil.h"
#import "YYModel.h"

@implementation SDConfigManager

#pragma mark - Singleton

+ (instancetype)sharedInstance {
    static id _sharedInstance = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        _sharedInstance = [[super allocWithZone:NULL] init];
    });
    return _sharedInstance;
}

+ (instancetype)allocWithZone:(struct _NSZone *)zone {
    return [[self class] sharedInstance];
}

//- (instancetype)copyWithZone:(NSZone *)zone {
//    return [[self class] sharedInstance];
//}
//
//- (instancetype)mutableCopyWithZone:(NSZone *)zone {
//    return [[self class] sharedInstance];
//}

#pragma mark - Init

- (instancetype)init {
    self = [super init];
    if (self) {
        [self setup];
    }
    return self;
}

- (void)setup {
    NSDictionary *jsonDict = [SDFileUtil loadJSONDictionaryFromBundle:@"global.json" optional:NO];
    self.config = [SDConfigModel yy_modelWithJSON:jsonDict];
}

@end
