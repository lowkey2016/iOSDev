//
//  SDIndustriesManager.h
//  slowdun3
//
//  Created by Jymn_Chen on 2018/3/20.
//  Copyright © 2018年 com.slowdun3. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "SDIndustryModel.h"

#define mSDIndustriesManager    [SDIndustriesManager sharedInstance]

/*
 *  !!! 注意 !!!
 *  如果要增加行业，在确定行业名后，需要在 Modules/Grep/utils/util_cons.py 中增加对应的行业，行业名称请保持一致
 */

@interface SDIndustriesManager : NSObject

+ (instancetype)sharedInstance;

@property (nonatomic, readonly, strong) SDIndustryModel *industry_unknown; // 未分类
@property (nonatomic, readonly, strong) SDIndustryModel *industry_eletric_all; // 家电行业
@property (nonatomic, readonly, strong) SDIndustryModel *industry_eletric_kitchen; // 厨电行业
@property (nonatomic, readonly, strong) SDIndustryModel *industry_vintage_sprit; // 白酒行业
@property (nonatomic, readonly, strong) SDIndustryModel *industry_fooddrink_condiment; // 调味品行业
@property (nonatomic, readonly, strong) SDIndustryModel *industry_realestate_all; // 房地产行业
@property (nonatomic, readonly, strong) SDIndustryModel *industry_realestate_ppp; // PPP房地产行业
@property (nonatomic, readonly, strong) SDIndustryModel *industry_cn_medicine_all; // 中药行业
@property (nonatomic, readonly, strong) SDIndustryModel *industry_airport_all; // 机场行业
@property (nonatomic, readonly, strong) SDIndustryModel *industry_st_all; // ST
@property (nonatomic, readonly, strong) SDIndustryModel *industry_paper_all; // 造纸行业

@end
