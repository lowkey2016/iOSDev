//
//  SDStockManager.m
//  slowdun3
//
//  Created by Jymn_Chen on 2018/3/20.
//  Copyright © 2018年 com.slowdun3. All rights reserved.
//

#import "SDStockManager.h"
#import "SDStockModel.h"
#import "SDIndustriesManager.h"

#define kSymbol @"symbol"
#define kName   @"name"

@interface SDStockManager ()

@property (nonatomic, strong) NSMutableDictionary<NSString *, SDStockModel *> *stocksInfo;

@end

@implementation SDStockManager

#pragma mark - Singleton

+ (instancetype)sharedInstance {
    static id _sharedInstance = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        _sharedInstance = [[super allocWithZone:NULL] init];
    });
    return _sharedInstance;
}

+ (instancetype)allocWithZone:(struct _NSZone *)zone {
    return [[self class] sharedInstance];
}

//- (instancetype)copyWithZone:(NSZone *)zone {
//    return [[self class] sharedInstance];
//}
//
//- (instancetype)mutableCopyWithZone:(NSZone *)zone {
//    return [[self class] sharedInstance];
//}

#pragma mark - Init

- (instancetype)init {
    self = [super init];
    if (self) {
        [self setup];
    }
    return self;
}

- (void)setup {
    self.stocksInfo = [NSMutableDictionary dictionary];
}

#pragma mark - Get Stock

- (SDStockModel *)stockWithSymbol:(NSString *)symbol {
    return _stocksInfo[symbol];
}

#pragma mark - Setup Stocks

- (void)setupStocks:(NSArray<NSDictionary<NSString *, NSString *> *> *)stocks industry:(SDIndustryModel *)industry {
    for (NSDictionary *dic in stocks) {
        SDStockModel *stk = [[SDStockModel alloc] initWithName:dic[kName] symbol:dic[kSymbol] yearFrom:self.yearFrom yearTo:self.yearTo industry:industry];
        _stocksInfo[stk.symbol] = stk;
    }
}

#warning - TODO 下面的全部写到配置文件中

// 家电行业
- (void)setup_industry_eletric_all {
    NSArray *arr = @[@{kSymbol : @"SZ000651", kName : @"格力电器"},
                     @{kSymbol : @"SZ000333", kName : @"美的集团"},
                     @{kSymbol : @"SH600690", kName : @"青岛海尔"},
                     ];
    SDIndustryModel *industry = mSDIndustriesManager.industry_eletric_all;
    [self setupStocks:arr industry:industry];
}

// 厨电行业
- (void)setup_industry_eletric_kitchen {
    NSArray *arr = @[@{kSymbol : @"SZ002508", kName : @"老板电器"},
                     @{kSymbol : @"SZ002032", kName : @"苏泊尔"},
                     @{kSymbol : @"SZ002035", kName : @"华帝股份"},
                     @{kSymbol : @"SZ002242", kName : @"九阳股份"},
                     @{kSymbol : @"SZ002403", kName : @"爱仕达"},
                     @{kSymbol : @"SZ002543", kName : @"万和电气"},
                     @{kSymbol : @"SZ002677", kName : @"浙江美大"},
                     ];
    SDIndustryModel *industry = mSDIndustriesManager.industry_eletric_kitchen;
    [self setupStocks:arr industry:industry];
}

// 白酒行业
- (void)setup_industry_vintage_sprit {
    NSArray *arr = @[@{kSymbol : @"SH600519", kName : @"贵州茅台"},
                     @{kSymbol : @"SZ000858", kName : @"五粮液"},
                     @{kSymbol : @"SZ000568", kName : @"泸州老窖"},
                     @{kSymbol : @"SZ002304", kName : @"洋河股份"},
                     @{kSymbol : @"SH600702", kName : @"舍得酒业"},
                     @{kSymbol : @"SZ000799", kName : @"酒鬼酒"},
                     @{kSymbol : @"SH603369", kName : @"今世缘"},
                     @{kSymbol : @"SZ000596", kName : @"古井贡酒"},
                     @{kSymbol : @"SH603589", kName : @"口子窖"},
                     @{kSymbol : @"SH600199", kName : @"金种子酒"},
                     @{kSymbol : @"SH603198", kName : @"迎驾贡酒"},
                     @{kSymbol : @"SH603919", kName : @"金徽酒"},
                     @{kSymbol : @"SH600197", kName : @"伊力特"},
                     ];
    SDIndustryModel *industry = mSDIndustriesManager.industry_vintage_sprit;
    [self setupStocks:arr industry:industry];
}

// 调味品行业
- (void)setup_industry_fooddrink_condiment {
    NSArray *arr = @[@{kSymbol : @"SH603288", kName : @"海天味业"},
                     @{kSymbol : @"SZ002650", kName : @"加加食品"},
                     @{kSymbol : @"SH603027", kName : @"千禾味业"},
                     @{kSymbol : @"SH600872", kName : @"中炬高新"},
                     @{kSymbol : @"SH600305", kName : @"恒顺醋业"},
                     ];
    SDIndustryModel *industry = mSDIndustriesManager.industry_fooddrink_condiment;
    [self setupStocks:arr industry:industry];
}

// 房地产行业
- (void)setup_industry_realestate_all {
    NSArray *arr = @[@{kSymbol : @"SZ000002", kName : @"万科A"},
                     @{kSymbol : @"SH600048", kName : @"保利地产"},
                     ];
    SDIndustryModel *industry = mSDIndustriesManager.industry_realestate_all;
    [self setupStocks:arr industry:industry];
}

// PPP房地产行业
- (void)setup_industry_realestate_ppp {
    NSArray *arr = @[@{kSymbol : @"SH600340", kName : @"华夏幸福"},
                     @{kSymbol : @"SZ002146", kName : @"荣盛发展"},
                     ];
    SDIndustryModel *industry = mSDIndustriesManager.industry_realestate_ppp;
    [self setupStocks:arr industry:industry];
}

// 中药行业
- (void)setup_industry_cn_medicine_all {
    NSArray *arr = @[@{kSymbol : @"SZ000423", kName : @"东阿阿胶"},
                     ];
    SDIndustryModel *industry = mSDIndustriesManager.industry_cn_medicine_all;
    [self setupStocks:arr industry:industry];
}

// 机场行业
- (void)setup_industry_airport_all {
    NSArray *arr = @[@{kSymbol : @"SH600009", kName : @"上海机场"},
                     @{kSymbol : @"SH600004", kName : @"白云机场"},
                     @{kSymbol : @"SZ000089", kName : @"深圳机场"},
                     @{kSymbol : @"SH600897", kName : @"厦门空港"},
                     ];
    SDIndustryModel *industry = mSDIndustriesManager.industry_airport_all;
    [self setupStocks:arr industry:industry];
}

// 造纸行业
- (void)setup_industry_paper_all {
    NSArray *arr = @[@{kSymbol : @"SZ000488", kName : @"晨鸣纸业"},
                     @{kSymbol : @"SZ002078", kName : @"太阳纸业"},
                     @{kSymbol : @"SZ002511", kName : @"中顺洁柔"},
                     ];
    SDIndustryModel *industry = mSDIndustriesManager.industry_paper_all;
    [self setupStocks:arr industry:industry];
}

// ST
- (void)setup_industry_st_all {
    NSArray *arr = @[@{kSymbol : @"SZ000972", kName : @"*ST中基"},
                     ];
    SDIndustryModel *industry = mSDIndustriesManager.industry_st_all;
    [self setupStocks:arr industry:industry];
}

// 未分类
- (void)setup_industry_unknown {
    NSArray *arr = @[@{kSymbol : @"SH600298", kName : @"安琪酵母"},
                     @{kSymbol : @"SH601238", kName : @"广汽集团"},
                     ];
    SDIndustryModel *industry = mSDIndustriesManager.industry_unknown;
    [self setupStocks:arr industry:industry];
}

#pragma mark - Common Methods

- (int32_t)yearFrom {
    return 2007;
}

- (int32_t)yearTo {
    return 2018;
}

@end
