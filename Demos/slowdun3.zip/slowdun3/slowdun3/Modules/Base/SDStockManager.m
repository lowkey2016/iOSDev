//
//  SDStockManager.m
//  slowdun3
//
//  Created by Jymn_Chen on 2018/3/20.
//  Copyright © 2018年 com.slowdun3. All rights reserved.
//

#import "SDStockManager.h"

// models
#import "SDStockModel.h"
#import "SDConfStockModel.h"

// managers
#import "SDIndustriesManager.h"
#import "SDConfigManager.h"

// utils
#import "SDFileUtil.h"
#import "YYModel.h"

@interface SDStockManager ()

@property (nonatomic, strong) NSMutableDictionary<NSString *, SDStockModel *> *stocksInfo;

@end

@implementation SDStockManager

#pragma mark - Singleton

+ (instancetype)sharedInstance {
    static id _sharedInstance = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        _sharedInstance = [[super allocWithZone:NULL] init];
    });
    return _sharedInstance;
}

+ (instancetype)allocWithZone:(struct _NSZone *)zone {
    return [[self class] sharedInstance];
}

//- (instancetype)copyWithZone:(NSZone *)zone {
//    return [[self class] sharedInstance];
//}
//
//- (instancetype)mutableCopyWithZone:(NSZone *)zone {
//    return [[self class] sharedInstance];
//}

#pragma mark - Init

- (instancetype)init {
    self = [super init];
    if (self) {
        [self setup];
    }
    return self;
}

- (void)setup {
    self.stocksInfo = [NSMutableDictionary dictionary];
}

#pragma mark - Get Stock

- (SDStockModel *)stockWithSymbol:(NSString *)symbol {
    return _stocksInfo[symbol];
}

#pragma mark - Setup Stocks

- (void)setupStocks:(SDIndustryModel *)industry {
    NSString *fileName = [NSString stringWithFormat:@"%@_stocks.json", industry.name];
    NSArray *jsonArr = [SDFileUtil loadJSONArrayFromBundle:fileName optional:NO];
    NSArray<SDConfStockModel *> *confStocks = [NSArray yy_modelArrayWithClass:[SDConfStockModel class] json:jsonArr];
    for (SDConfStockModel *conf in confStocks) {
        SDStockModel *stk = [[SDStockModel alloc] initWithName:conf.name symbol:conf.symbol yearFrom:mSDConfig.yearFrom yearTo:mSDConfig.yearTo industry:industry];
        _stocksInfo[stk.symbol] = stk;
    }
}

#define IMP_setupIndustry  \
{   \
    NSString *cmd = NSStringFromSelector(_cmd); \
    NSString *industryName = [cmd substringFromIndex:@"setup_".length]; \
    [self setupStocks:[mSDIndustriesManager valueForKey:industryName]];  \
}

// 家电行业
- (void)setup_industry_eletric_all IMP_setupIndustry

// 厨电行业
- (void)setup_industry_eletric_kitchen IMP_setupIndustry

// 白酒行业
- (void)setup_industry_vintage_sprit IMP_setupIndustry

// 调味品行业
- (void)setup_industry_fooddrink_condiment IMP_setupIndustry

// 房地产行业
- (void)setup_industry_realestate_all IMP_setupIndustry

// PPP房地产行业
- (void)setup_industry_realestate_ppp IMP_setupIndustry

// 中药行业
- (void)setup_industry_cn_medicine_all IMP_setupIndustry

// 机场行业
- (void)setup_industry_airport_all IMP_setupIndustry

// 造纸行业
- (void)setup_industry_paper_all IMP_setupIndustry

// ST
- (void)setup_industry_st_all IMP_setupIndustry

// 未分类
- (void)setup_industry_unknown IMP_setupIndustry

@end
