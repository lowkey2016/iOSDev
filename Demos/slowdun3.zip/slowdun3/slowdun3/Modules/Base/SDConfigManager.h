//
//  SDConfigManager.h
//  slowdun3
//
//  Created by Jymn_Chen on 2018/3/25.
//  Copyright © 2018年 com.slowdun3. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "SDConfigModel.h"

#define mSDConfig    [SDConfigManager sharedInstance].config

@interface SDConfigManager : NSObject

+ (instancetype)sharedInstance;

SD_PROPERTY_STRONG SDConfigModel *config;

@end
