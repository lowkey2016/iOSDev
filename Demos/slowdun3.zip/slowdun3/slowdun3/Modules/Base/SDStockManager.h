//
//  SDStockManager.h
//  slowdun3
//
//  Created by Jymn_Chen on 2018/3/20.
//  Copyright © 2018年 com.slowdun3. All rights reserved.
//

#import <Foundation/Foundation.h>

@class SDStockModel;

#define mSDStockManager [SDStockManager sharedInstance]

@interface SDStockManager : NSObject

+ (instancetype)sharedInstance;

- (SDStockModel *)stockWithSymbol:(NSString *)symbol;

// 家电行业
- (void)setup_industry_eletric_all;

// 厨电行业
- (void)setup_industry_eletric_kitchen;

// 白酒行业
- (void)setup_industry_vintage_sprit;

// 调味品行业
- (void)setup_industry_fooddrink_condiment;

// 房地产行业
- (void)setup_industry_realestate_all;

// PPP房地产行业
- (void)setup_industry_realestate_ppp;

// 中药行业
- (void)setup_industry_cn_medicine_all;

// 机场行业
- (void)setup_industry_airport_all;

// 造纸行业
- (void)setup_industry_paper_all;

// ST
- (void)setup_industry_st_all;

// 未分类
- (void)setup_industry_unknown;

@end
