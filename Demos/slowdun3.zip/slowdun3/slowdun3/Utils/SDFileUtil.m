//
//  SDFileUtil.m
//  slowdun3
//
//  Created by Jymn_Chen on 2018/3/19.
//  Copyright © 2018年 com.slowdun3. All rights reserved.
//

#import "SDFileUtil.h"
#import "HGCFileManager.h"

@implementation SDFileUtil

#pragma mark - Load JSON

+ (NSDictionary *)loadJSONDictionaryFromBundle:(NSString *)fileName optional:(BOOL)isOptional {
    if (![fileName hasSuffix:@".json"]) {
        fileName = [fileName stringByAppendingString:@".json"];
    }
    
    NSError *err;
    NSString *filePath = [[NSBundle mainBundle] pathForResource:fileName ofType:nil];
    NSData *jsonData = [[NSData alloc] initWithContentsOfFile:filePath];
    if (isOptional && !jsonData) {
        return nil;
    }
    NSDictionary *jsonDict = [NSJSONSerialization JSONObjectWithData:jsonData options:NSJSONReadingAllowFragments error:&err];
    NSAssert(jsonDict && [jsonDict isKindOfClass:[NSDictionary class]] && !err, err.localizedDescription);
    return jsonDict;
}

+ (NSArray *)loadJSONArrayFromBundle:(NSString *)fileName optional:(BOOL)isOptional {
    if (![fileName hasSuffix:@".json"]) {
        fileName = [fileName stringByAppendingString:@".json"];
    }
    
    NSError *err;
    NSString *filePath = [[NSBundle mainBundle] pathForResource:fileName ofType:nil];
    NSData *jsonData = [[NSData alloc] initWithContentsOfFile:filePath];
    if (isOptional && !jsonData) {
        return nil;
    }
    NSArray *jsonArr = [NSJSONSerialization JSONObjectWithData:jsonData options:NSJSONReadingAllowFragments error:&err];
    NSAssert(jsonArr && [jsonArr isKindOfClass:[NSArray class]] && !err, err.localizedDescription);
    return jsonArr;
}

#pragma mark - Save Data

+ (BOOL)overwriteString:(NSString *)content toFile:(NSString *)filePath {
    NSData *buffer = [content dataUsingEncoding:NSUTF8StringEncoding];
    return [self overwriteData:buffer toFile:filePath];
}

+ (BOOL)overwriteData:(NSData *)data toFile:(NSString *)filePath {
    if (!filePath || !data || data.length == 0) {
        return NO;
    }
    
    return [mHGCFileManager saveData:data toFilePath:filePath];
}

+ (BOOL)appendString:(NSString *)content toFile:(NSString *)filePath atNewLine:(BOOL)newline {
    NSData *buffer = [content dataUsingEncoding:NSUTF8StringEncoding];
    return [self appendData:buffer toFile:filePath atNewLine:newline];
}

+ (BOOL)appendData:(NSData *)data toFile:(NSString *)filePath atNewLine:(BOOL)newline {
    if (!filePath || !data || data.length == 0) {
        return NO;
    }
    
    if (![mHGCFileManager fileExistsAtPath:filePath]) {
        return [mHGCFileManager saveData:data toFilePath:filePath];
    }
    
    NSFileHandle *handle = [NSFileHandle fileHandleForWritingAtPath:filePath];
    NSAssert(handle != nil, @"open %@ fail", filePath);
    if (!handle) {
        return NO;
    }
    
    [handle seekToEndOfFile];
    if (newline) {
        [handle writeData:[@"\r\n" dataUsingEncoding:NSUTF8StringEncoding]];
    }
    [handle writeData:data];
    [handle closeFile];
    return YES;
}

#pragma mark - HTML

+ (BOOL)saveHTML:(NSString *)htmlStr to:(NSString *)filePath {
    if (![filePath hasSuffix:@".html"]) {
        filePath = [filePath stringByAppendingString:@".html"];
    }
    return [self overwriteString:htmlStr toFile:filePath];
}

@end
