//
//  SDMathUtil.m
//  slowdun3
//
//  Created by Jymn_Chen on 2018/3/19.
//  Copyright © 2018年 com.slowdun3. All rights reserved.
//

#import "SDMathUtil.h"

@implementation SDMathUtil

+ (CGFloat)safeDivide:(CGFloat)x to:(CGFloat)y {
    if (y <= 0) {
        return 0.0;
    } else {
        return (CGFloat)x / (CGFloat)y;
    }
}

@end
