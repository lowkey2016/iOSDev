//
//  SDFileUtil.h
//  slowdun3
//
//  Created by Jymn_Chen on 2018/3/19.
//  Copyright © 2018年 com.slowdun3. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface SDFileUtil : NSObject

// DocumentsPath: /Users/apple/Library/Containers/com.slowdun.slowdun3/Data/Documents
// CachesPath: /Users/apple/Library/Containers/com.slowdun.slowdun3/Data/Library/Caches

+ (NSDictionary *)loadJSONDictionaryFromBundle:(NSString *)fileName optional:(BOOL)isOptional;
+ (NSArray *)loadJSONArrayFromBundle:(NSString *)fileName optional:(BOOL)isOptional;

+ (BOOL)overwriteString:(NSString *)content toFile:(NSString *)filePath;
+ (BOOL)overwriteData:(NSData *)data toFile:(NSString *)filePath;
+ (BOOL)appendString:(NSString *)content toFile:(NSString *)filePath atNewLine:(BOOL)newline;
+ (BOOL)appendData:(NSData *)data toFile:(NSString *)filePath atNewLine:(BOOL)newline;

+ (BOOL)saveHTML:(NSString *)htmlStr to:(NSString *)filePath;

@end
