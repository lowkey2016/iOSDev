//
//  SDMathUtil.h
//  slowdun3
//
//  Created by Jymn_Chen on 2018/3/19.
//  Copyright © 2018年 com.slowdun3. All rights reserved.
//

#import <Foundation/Foundation.h>

#define SDSafeDivide(x, y)  [SDMathUtil safeDivide:(x) to:(y)]

@interface SDMathUtil : NSObject

+ (CGFloat)safeDivide:(CGFloat)x to:(CGFloat)y;

@end
