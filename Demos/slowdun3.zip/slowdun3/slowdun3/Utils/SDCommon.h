//
//  SDCommon.h
//  slowdun3
//
//  Created by Jymn_Chen on 2018/3/19.
//  Copyright © 2018年 com.slowdun3. All rights reserved.
//

#ifndef SDCommon_h
#define SDCommon_h

#import <Foundation/Foundation.h>

#define SD_PROPERTY_ASSIGN  @property (nonatomic, assign)
#define SD_PROPERTY_COPY    @property (nonatomic, copy)
#define SD_PROPERTY_STRONG  @property (nonatomic, strong)

#define SD_PROPERTY_ASSIGN_FLOAT    @property (nonatomic, assign) CGFloat
#define SD_PROPERTY_ASSIGN_BOOL    @property (nonatomic, assign) BOOL
#define SD_PROPERTY_ASSIGN_INT32    @property (nonatomic, assign) int32_t
#define SD_PROPERTY_COPY_STR    @property (nonatomic, copy) NSString *

#define SDAssertNotNil(obj) NSAssert(obj != nil, nil)
#define SDAssertNil(obj) NSAssert(obj == nil, nil)
#define SDAssertIsClass(obj, cls) NSAssert(obj && [obj isKindOfClass:cls], nil)
#define SDAssertStrEq(s1, s2)   NSAssert([s1 isEqualToString:s2], nil)
#define SDAssertFloatEq(s1, s2) NSAssert(s1 == s2, nil)
#define SDAssertIntEq(s1, s2)   NSAssert(s1 == s2, nil)

#endif /* SDCommon_h */
