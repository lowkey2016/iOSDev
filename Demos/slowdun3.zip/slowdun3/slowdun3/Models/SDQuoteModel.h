//
//  SDQuoteModel.h
//  slowdun3
//
//  Created by Jymn_Chen on 2018/3/19.
//  Copyright © 2018年 com.slowdun3. All rights reserved.
//
//  市场数据

#import <Foundation/Foundation.h>
#import "SDCommon.h"

@interface SDQuoteModel : NSObject

SD_PROPERTY_ASSIGN_FLOAT current; // 当前股价
SD_PROPERTY_ASSIGN_FLOAT totalShares; // 总股本
SD_PROPERTY_ASSIGN_FLOAT float_shares; // 流通股本
SD_PROPERTY_ASSIGN_FLOAT dividend; // 每股股息

SD_PROPERTY_COPY_STR time; // 记录的时间
SD_PROPERTY_COPY_STR currency_unit; // 货币单位，例如 CNY

@end
