//
//  SDStockModel.m
//  slowdun3
//
//  Created by Jymn_Chen on 2018/3/19.
//  Copyright © 2018年 com.slowdun3. All rights reserved.
//

#import "SDStockModel.h"
#import "SDMathUtil.h"
#import "SDFileUtil.h"
#import "YYModel.h"

#define SDCheckReportDate_OnlyYear(dateKey)   \
    if (![dict[dateKey] hasSuffix:@"1231"]) { \
        return; \
    }   \
    NSNumber *year = @([[dict[dateKey] substringToIndex:4] intValue]);    \
    NSAssert(year.intValue > 1990 && year.intValue < 2100, @"year is invalid"); \
    if (year.intValue < _expectedYearFrom || year.intValue > _expectedYearTo) {   \
        return; \
    }

#define SDCheckReportDate_All(dateKey)   \
    NSNumber *year = @([[dict[dateKey] substringToIndex:4] intValue]);    \
    NSAssert(year.intValue > 1990 && year.intValue < 2100, @"year is invalid"); \
    if (year.intValue < _expectedYearFrom || year.intValue > _expectedYearTo) {   \
        return; \
    }

@interface SDStockModel ()

@end

@implementation SDStockModel

#pragma mark - Init

- (instancetype)initWithName:(NSString *)name symbol:(NSString *)symbol yearFrom:(int32_t)yearFrom yearTo:(int32_t)yearTo industry:(SDIndustryModel *)industry {
    NSAssert(name && name.length > 0, @"name is empty");
    NSAssert(symbol && symbol.length > 0, @"symbol is empty");
    NSAssert(industry, @"industry is empty");
    
    self = [super init];
    if (self) {
        _name = name;
        _symbol = symbol;
        _expectedYearFrom = yearFrom;
        _expectedYearTo = yearTo;
        _industry = industry;
        [self setup];
    }
    return self;
}

- (void)setup {
    NSDictionary *jsonDict;
    
    jsonDict = [self loadJSONDictionary:@"zcfzb"];
    [self parseAssetTables:jsonDict];
    
    jsonDict = [self loadJSONDictionary:@"gslrb"];
    [self parseProfitTables:jsonDict];
    
    jsonDict = [self loadJSONDictionary:@"xjllb"];
    [self parseCashTables:jsonDict];
    
    jsonDict = [self loadJSONDictionary:@"quote"];
    [self parseQuote:jsonDict];
    
    jsonDict = [self loadJSONDictionary:@"bonus"];
    [self parseBonusTables:jsonDict];
    
    jsonDict = [self loadJSONDictionary:@"fjsj" optional:YES];
    if (jsonDict) {
        [self parseManualTables:jsonDict];
    }
    
    [self confirmSupportedYears];
    [self generateMixTables]; // 在 supportedYears 赋值后调用
}

- (void)confirmSupportedYears {
    NSSet<NSNumber *> *assetYears = [NSSet setWithArray:_assets.allKeys];
    NSSet<NSNumber *> *profitYears = [NSSet setWithArray:_profits.allKeys];
    NSSet<NSNumber *> *cashYears = [NSSet setWithArray:_cashes.allKeys];
    NSMutableSet<NSNumber *> *desSet = assetYears.mutableCopy;
    [desSet intersectSet:profitYears];
    [desSet intersectSet:cashYears];
    NSMutableArray<NSNumber *> *sortedYears = [desSet allObjects].mutableCopy;
    [sortedYears sortUsingComparator:^NSComparisonResult(NSNumber * _Nonnull obj1, NSNumber * _Nonnull obj2) {
        return obj1.intValue < obj2.intValue;
    }];
    self.supportedYears = sortedYears.copy;
}

#pragma mark - Load and Parse JSON

- (NSDictionary *)loadJSONDictionary:(NSString *)type {
    return [self loadJSONDictionary:type optional:NO];
}

- (NSDictionary *)loadJSONDictionary:(NSString *)type optional:(BOOL)isOptional {
    NSString *fileName = [NSString stringWithFormat:@"%@_%@_%@.json", _symbol, _name, type];
    return [SDFileUtil loadJSONDictionaryFromBundle:fileName optional:isOptional];
}

- (void)parseAssetTables:(NSDictionary *)jsonDict {
    @autoreleasepool {
        NSMutableDictionary<NSNumber *, SDAssetModel *> *desDict = [NSMutableDictionary dictionary];
        NSArray<NSDictionary *> *jsonArr = jsonDict[@"list"];
        [jsonArr enumerateObjectsUsingBlock:^(NSDictionary * _Nonnull dict, NSUInteger idx, BOOL * _Nonnull stop) {
            SDCheckReportDate_OnlyYear(@"reportdate")
            SDAssetModel *model = [SDAssetModel yy_modelWithDictionary:dict];
            NSAssert(model && [model isKindOfClass:[SDAssetModel class]], @"assetModel invalid");
            desDict[year] = model;
        }];
        
        NSAssert(desDict.count > 0, @"no data in asset tables");
        self.assets = desDict.copy;
    }
}

- (void)parseProfitTables:(NSDictionary *)jsonDict {
    @autoreleasepool {
        NSMutableDictionary<NSNumber *, SDProfitModel *> *desDict = [NSMutableDictionary dictionary];
        NSArray<NSDictionary *> *jsonArr = jsonDict[@"list"];
        [jsonArr enumerateObjectsUsingBlock:^(NSDictionary * _Nonnull dict, NSUInteger idx, BOOL * _Nonnull stop) {
            SDCheckReportDate_OnlyYear(@"enddate")
            SDProfitModel *model = [SDProfitModel yy_modelWithDictionary:dict];
            NSAssert(model && [model isKindOfClass:[SDProfitModel class]], @"profitModel invalid");
            desDict[year] = model;
        }];
        
        NSAssert(desDict.count > 0, @"no data in profit tables");
        self.profits = desDict.copy;
    }
}

- (void)parseCashTables:(NSDictionary *)jsonDict {
    @autoreleasepool {
        NSMutableDictionary<NSNumber *, SDCashModel *> *desDict = [NSMutableDictionary dictionary];
        NSArray<NSDictionary *> *jsonArr = jsonDict[@"list"];
        [jsonArr enumerateObjectsUsingBlock:^(NSDictionary * _Nonnull dict, NSUInteger idx, BOOL * _Nonnull stop) {
            SDCheckReportDate_OnlyYear(@"enddate")
            SDCashModel *model = [SDCashModel yy_modelWithDictionary:dict];
            NSAssert(model && [model isKindOfClass:[SDCashModel class]], @"cashModel invalid");
            desDict[year] = model;
        }];
        
        NSAssert(desDict.count > 0, @"no data in cash tables");
        self.cashes = desDict.copy;
    }
}

- (void)parseQuote:(NSDictionary *)jsonDict {
    SDQuoteModel *model = [SDQuoteModel yy_modelWithDictionary:jsonDict[_symbol]];
    NSAssert(model && [model isKindOfClass:[SDQuoteModel class]], @"quoteModel invalid");
    self.quote = model;
}

- (void)parseBonusTables:(NSDictionary *)jsonDict {
    @autoreleasepool {
        NSMutableDictionary<NSNumber *, SDBonusModel *> *desDict = [NSMutableDictionary dictionary];
        NSArray<NSDictionary *> *jsonArr = jsonDict[@"list"];
        [jsonArr enumerateObjectsUsingBlock:^(NSDictionary * _Nonnull dict, NSUInteger idx, BOOL * _Nonnull stop) {
            SDCheckReportDate_All(@"bonusimpdate")
            SDBonusModel *model = [SDBonusModel yy_modelWithDictionary:dict];
            NSAssert(model && [model isKindOfClass:[SDBonusModel class]], @"bonusModel invalid");
            desDict[model.bonusimpdate] = model; // 注: 一年可能多次分红，所以这里不以年份为 key，而是用具体的分红公告日期
        }];
        
        NSAssert(desDict.count > 0, @"no data in bonus tables");
        self.bonuses = desDict.copy;
    }
}

- (void)parseManualTables:(NSDictionary *)jsonDict {
    @autoreleasepool {
        NSMutableDictionary<NSNumber *, SDManualModel *> *desDict = [NSMutableDictionary dictionary];
        NSArray<NSDictionary *> *jsonArr = jsonDict[@"list"];
        [jsonArr enumerateObjectsUsingBlock:^(NSDictionary * _Nonnull dict, NSUInteger idx, BOOL * _Nonnull stop) {
            SDCheckReportDate_OnlyYear(@"reportdate")
            SDManualModel *model = [SDManualModel yy_modelWithDictionary:dict];
            NSAssert(model && [model isKindOfClass:[SDManualModel class]], @"manualModel invalid");
            desDict[year] = model;
        }];
        
        NSAssert(desDict.count > 0, @"no data in manual tables");
        self.manuals = desDict.copy;
    }
}

- (void)generateMixTables {
    NSAssert(_supportedYears.count > 0, @"supportedYears not setup");
    @autoreleasepool {
        NSMutableDictionary<NSNumber *, SDMixModel *> *desDict = [NSMutableDictionary dictionary];
        // 必须从最老的年份开始算起，因为新的年份可能会用到老的年份的数据
        for (NSInteger i = _supportedYears.count - 1; i >= 0; i--) {
            NSNumber *year = _supportedYears[i];
            SDMixModel *model = [self generateMixData:year];
            NSAssert(model && [model isKindOfClass:[SDMixModel class]], @"mixModel invalid");
            desDict[year] = model;
        }
    }
}

- (SDMixModel *)generateMixData:(NSNumber *)year {
    NSAssert(year, @"year is nil");
    NSNumber *lastYear = @(year.intValue - 1);
    NSNumber *beforeLastYear = @(year.intValue - 1);
    
    SDAssetModel *asset = _assets[year];
    SDAssetModel *lstAsset = _assets[lastYear];
    SDAssetModel *befLstAsset = _assets[beforeLastYear];
    
    SDProfitModel *profit = _profits[year];
    SDProfitModel *lstProfit = _profits[lastYear];
    SDProfitModel *befLstProfit = _profits[beforeLastYear];
    
    SDCashModel *cash = _cashes[year];
    SDManualModel *manual = _manuals[year];
    SDMixModel *lstMix = _mixes[lastYear];
    
    SDMixModel *model = [SDMixModel new];
    model.year = year.intValue;
    
    // 资本支出 = 购建固定资产、无形资产和其他长期资产所支付的现金 + 取得子公司及其他营业单位支付的现金净额 + 财报中记录的开发支出
    // 这个必须首先设置，下面会用到
    model.capitalexp = cash.acquassetcash + cash.subspaynetcash + manual.findevexp;
    
    // 股东利润 = 报告利润 A (归属于母公司所有者净利润) + 折扣、摊销与其它成本 B - 维持公司长期竞争地位的资本支出 C
    // 这个必须在前面设置，下面会用到
    model.shareprofit = profit.parenetp + cash.depamortot - model.capitalexp;
    
    // 简化的自由现金流 = 经营现金流净额 - 资本支出
    model.simfreecashflow = cash.mananetr - model.capitalexp;
    
    /// 是否小投入大产出参数
    // 当年的扣除非经常性损益营业利润 / 去年的资本支出
    model.curprof_div_lstcapexp = SDSafeDivide(profit.rmlosgainperprofit, lstMix.capitalexp);
    // (当年扣除非经常性损益营业利润 - 去年扣除非经常性损益营业利润) / 去年的资本支出
    model.profchg_div_lstcapexp = SDSafeDivide(profit.rmlosgainperprofit - lstProfit.rmlosgainperprofit, lstMix.capitalexp);
    // (当年扣除非经常性损益营业利润 - 去年扣除非经常性损益营业利润) / (去年的股东权益 - 前年的股东权益)
    model.profchg_div_lstrigchg = SDSafeDivide(profit.rmlosgainperprofit - lstProfit.rmlosgainperprofit, lstAsset.righaggr - befLstAsset.righaggr);
    
    /// 留存利润使用效率
    // 累计归属于母公司所有者净利润 / 投入的股东权益 = ( 税后归母净利润Y1 + 税后归母净利润Y1+1 + … + 税后归母净利润Y2 ) / ( 股东权益Y2 - 股东权益Y1 )，每 3 年一个周期
    model.profsum_div_righin_3y = SDSafeDivide(profit.parenetp + lstProfit.parenetp + befLstProfit.parenetp, asset.righaggr - befLstAsset.righaggr);
    // 累计归属于母公司所有者净利润 / 留存利润 = ( 税后归母净利润Y1 + 税后归母净利润Y1+1 + … + 税后归母净利润Y2 ) / ( 留存利润Y2 - 留存利润Y1 )，每 3 年一个周期
    model.profsum_div_stayprof_3y = SDSafeDivide(profit.parenetp + lstProfit.parenetp + befLstProfit.parenetp, asset.undiprof - befLstAsset.undiprof);
    
    /// ROE 和 ROA
    // 本期 ROE = 归属于母公司所有者净利润 / 上期净资产
    model.roe_this = SDSafeDivide(profit.parenetp, lstAsset.righaggr);
    // 加权平均净资产收益率 ROE = 归属于母公司所有者净利润 / 平均净资产
    model.roe_ave = SDSafeDivide(profit.parenetp, (asset.righaggr + lstAsset.righaggr) / 2);
    // 本期 ROA = 归属于母公司所有者净利润 / 上期总资产
    model.roa_this = SDSafeDivide(profit.parenetp, lstAsset.totasset);
    // 加权平均总资产收益率 ROA = 归属于母公司所有者净利润 / 平均总资产
    model.roa_ave = SDSafeDivide(profit.parenetp, (asset.totasset + lstAsset.totasset) / 2);
    // 股东利润本期 ROE = 股东利润 / 上期净资产
    model.roe_sp_this = SDSafeDivide(model.shareprofit, lstAsset.righaggr);
    // 股东利润加权平均 ROE = 股东利润 / 平均净资产
    model.roe_sp_ave = SDSafeDivide(model.shareprofit, (asset.righaggr + lstAsset.righaggr) / 2);
    // 股东利润本期 ROA = 股东利润 / 上期总资产
    model.roa_sp_this = SDSafeDivide(model.shareprofit, lstAsset.totasset);
    // 股东利润加权平均 ROA = 股东利润 / 平均总资产
    model.roa_sp_ave = SDSafeDivide(model.shareprofit, (asset.totasset + lstAsset.totasset) / 2);
    
    // 现金回收率
    model.coe_ave = SDSafeDivide(cash.mananetr, (asset.righaggr + lstAsset.righaggr) / 2);
    model.coa_ave = SDSafeDivide(cash.mananetr, (asset.totasset + lstAsset.totasset) / 2);
    
    /// 周转率相关
    // 存货周转率 = 营业成本 / 存货平均余额
    model.inve_torate = SDSafeDivide(profit.bizcost, (asset.inve + lstAsset.inve) / 2);
    // 存货周转天数 = 360 / 存货周转率
    model.inve_todays = SDSafeDivide(360, model.inve_torate);
    // 应收账款周转率 = 营业收入 / 平均应收账款
    model.accorece_torate = SDSafeDivide(profit.bizinco, (asset.accorece + lstAsset.accorece) / 2);
    // 应收账款周转天数 = 360 / 应收账款周转率
    model.accorece_todays = SDSafeDivide(360, model.accorece_torate);
    // 应付账款周转率 = 营业收入 / 平均应付账款
    model.accopaya_torate = SDSafeDivide(profit.bizinco, (asset.accopaya + lstAsset.accopaya) / 2);
    // 应付账款周转天数 = 360 / 应付账款周转率
    model.accopaya_todays = SDSafeDivide(360, model.accopaya_torate);
    // 资金周转周期 = 存货周转天数 + 应收账款周转天数 - 应付账款周转天数
    model.turnoverdays = model.inve_todays + model.accorece_todays - model.accopaya_todays;
    
    return model;
}

@end
