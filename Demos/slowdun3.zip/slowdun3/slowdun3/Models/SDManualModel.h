//
//  SDManualModel.h
//  slowdun3
//
//  Created by Jymn_Chen on 2018/3/19.
//  Copyright © 2018年 com.slowdun3. All rights reserved.
//
//  人工录入的财报数据
//  如果明细需要截图，就不要填文字了

#import "SDBaseModel.h"
#import "SDCommon.h"

/**
 JSON 格式:
 {
    "list" : [
        {
            "reportdate" : "xxx",
            ...
        },
        ...
    ]
 }
 */

@interface SDManualModel : SDBaseModel

SD_PROPERTY_COPY_STR basedesc; // 公司基本情况

SD_PROPERTY_COPY_STR reportdate; // 报表日期
SD_PROPERTY_COPY_STR finstmtcomments; // 财报意见
SD_PROPERTY_COPY_STR acntfirm; // 会计师事务所
SD_PROPERTY_COPY_STR finstmtspecials; // 董事会在财报中提出的注意事项
SD_PROPERTY_ASSIGN_BOOL has_acnt_policy_chg; // 是否有会计政策变更
SD_PROPERTY_ASSIGN_BOOL has_acnt_estm_chg; // 是否有会计估计变更
SD_PROPERTY_ASSIGN_BOOL has_acnt_err_cort; // 是否有前期会计差错更正

SD_PROPERTY_ASSIGN_FLOAT curfds_cash; // 货币资金中的库存现金
SD_PROPERTY_ASSIGN_FLOAT curfds_bank; // 货币资金中的银行存款
SD_PROPERTY_ASSIGN_FLOAT curfds_other; // 货币资金中的其他货币资金
SD_PROPERTY_ASSIGN_FLOAT curfds_limit; // 货币资金中的使用受限资金

SD_PROPERTY_ASSIGN_FLOAT notesrece_bank; // 应收票据中的银行承兑汇票
SD_PROPERTY_ASSIGN_FLOAT notesrece_business; // 应收票据中的商业承兑汇票
SD_PROPERTY_ASSIGN_FLOAT notesrece_other; // 应收票据中的其它部分

SD_PROPERTY_COPY_STR accorece_bad_standard; // 应收账款的坏账计提标准
SD_PROPERTY_ASSIGN_FLOAT accorece_single_imp_tot; // 期末单项金额重大并单项计坏账准备的应收账款
SD_PROPERTY_ASSIGN_FLOAT accorece_single_imp_bad; // 期末单项金额重大并单项计坏账准备的应收账款坏账准备
SD_PROPERTY_ASSIGN_FLOAT accorece_single_tot; // 单项金额不重大但单独计坏账准备的应收账款
SD_PROPERTY_ASSIGN_FLOAT accorece_single_bad; // 单项金额不重大但单独计坏账准备的应收账款坏账准备
SD_PROPERTY_ASSIGN_FLOAT accorece_credit_tot; // 按信用风险特征组合计坏账准备的应收账款
SD_PROPERTY_ASSIGN_FLOAT accorece_credit_bad; // 按信用风险特征组合计坏账准备的应收账款坏账准备
SD_PROPERTY_ASSIGN_FLOAT accorece_0_1_tot; // 账龄小于1年的应收账款
SD_PROPERTY_ASSIGN_FLOAT accorece_0_1_bad; // 账龄小于1年的应收账款坏账准备
SD_PROPERTY_ASSIGN_FLOAT accorece_1_2_tot; // 账龄1-2年的应收账款
SD_PROPERTY_ASSIGN_FLOAT accorece_1_2_bad; // 账龄1-2年的应收账款坏账准备
SD_PROPERTY_ASSIGN_FLOAT accorece_2_3_tot; // 账龄2-3年的应收账款
SD_PROPERTY_ASSIGN_FLOAT accorece_2_3_bad; // 账龄2-3年的应收账款坏账准备
SD_PROPERTY_ASSIGN_FLOAT accorece_3_4_tot; // 账龄3-4年的应收账款
SD_PROPERTY_ASSIGN_FLOAT accorece_3_4_bad; // 账龄3-4年的应收账款坏账准备
SD_PROPERTY_ASSIGN_FLOAT accorece_4_5_tot; // 账龄4-5年的应收账款
SD_PROPERTY_ASSIGN_FLOAT accorece_4_5_bad; // 账龄4-5年的应收账款坏账准备
SD_PROPERTY_ASSIGN_FLOAT accorece_5_n_tot; // 账龄大于5年的应收账款
SD_PROPERTY_ASSIGN_FLOAT accorece_5_n_bad; // 账龄大于5年的应收账款坏账准备
SD_PROPERTY_ASSIGN_FLOAT prep_0_1; // 1年内的预付款项
SD_PROPERTY_ASSIGN_FLOAT otherrecebad; // 其它应收款坏账准备总和

SD_PROPERTY_COPY_STR inverevvallossstandard; // 存货跌价计提标准
SD_PROPERTY_ASSIGN_FLOAT inverevvallosstot; // 存货跌价计提总额
SD_PROPERTY_COPY_STR inve_unit; // 产销存单位
SD_PROPERTY_ASSIGN_FLOAT inve_prod; // 存货产量
SD_PROPERTY_ASSIGN_FLOAT inve_sale; // 存货销量
SD_PROPERTY_ASSIGN_FLOAT inve_save; // 存货存量

SD_PROPERTY_COPY_STR fixedassedepolicy; // 固定资产的折旧政策
SD_PROPERTY_COPY_STR intaassetdmopolicy; // 无形资产的摊销政策
SD_PROPERTY_ASSIGN_FLOAT unoperintaasset; // 和主营业务无关的无形资产总额（例如土地使用权和软件使用权之外的“知识产权型”）
SD_PROPERTY_ASSIGN_FLOAT findevexp; // 财报中记录的开发支出

SD_PROPERTY_COPY_STR invepropcal; // 投资性房地产的计量模式

SD_PROPERTY_ASSIGN_FLOAT saletax; // 营业税金及附加的消费税
SD_PROPERTY_ASSIGN_FLOAT resourcetax; // 营业税金及附加的资源税

SD_PROPERTY_ASSIGN_FLOAT emplyescnt; // 公司员工总数

// 应收账款之和
- (CGFloat)accorecetot;
// 应收账款坏账计提总额
- (CGFloat)accorece_bad_tot;
// 应收账款坏账计提比例
- (CGFloat)accorece_bad_rate;

// 产、销、存量之和
- (CGFloat)inve_prodsalesave;
// 产量和存量之和
- (CGFloat)inve_prodandsave;

@end
