//
//  SDProfitModel.h
//  slowdun3
//
//  Created by Jymn_Chen on 2018/3/19.
//  Copyright © 2018年 com.slowdun3. All rights reserved.
//
//  利润表

#import "SDBaseModel.h"
#import "SDCommon.h"

@interface SDProfitModel : SDBaseModel

SD_PROPERTY_COPY_STR begindate;
SD_PROPERTY_COPY_STR enddate;

SD_PROPERTY_ASSIGN_FLOAT biztotinco; // 营业总收入
SD_PROPERTY_ASSIGN_FLOAT bizinco; // 营业收入
SD_PROPERTY_ASSIGN_FLOAT inteinco; // 利息收入
SD_PROPERTY_ASSIGN_FLOAT realsale; // 房地产销售收入
SD_PROPERTY_ASSIGN_FLOAT otherbizinco; // 其他业务收入

SD_PROPERTY_ASSIGN_FLOAT biztotcost; // 营业总成本
SD_PROPERTY_ASSIGN_FLOAT bizcost; // 营业成本
SD_PROPERTY_ASSIGN_FLOAT inteexpe; // 利息支出
SD_PROPERTY_ASSIGN_FLOAT realsalecost; // 房地产销售成本
SD_PROPERTY_ASSIGN_FLOAT deveexpe; // 研发费用
SD_PROPERTY_ASSIGN_FLOAT otherbizcost; // 其他业务成本
SD_PROPERTY_ASSIGN_FLOAT biztax; // 营业税金及附加
SD_PROPERTY_ASSIGN_FLOAT salesexpe; // 销售费用
SD_PROPERTY_ASSIGN_FLOAT manaexpe; // 管理费用
SD_PROPERTY_ASSIGN_FLOAT finexpe; // 财务费用
SD_PROPERTY_ASSIGN_FLOAT asseimpaloss; // 资产减值损失

SD_PROPERTY_ASSIGN_FLOAT valuechgloss; // 公允价值变动收益
SD_PROPERTY_ASSIGN_FLOAT inveinco; // 投资收益
SD_PROPERTY_ASSIGN_FLOAT assoinveprof; // 其中:对联营企业和合营企业的投资收益
SD_PROPERTY_ASSIGN_FLOAT exchggain; // 汇兑收益
SD_PROPERTY_ASSIGN_FLOAT otherbizprof; // 其他业务利润

SD_PROPERTY_ASSIGN_FLOAT perprofit; // 营业利润
SD_PROPERTY_ASSIGN_FLOAT nonoreve; // 营业外收入
SD_PROPERTY_ASSIGN_FLOAT nonoexpe; // 营业外支出
SD_PROPERTY_ASSIGN_FLOAT noncassetsdisl; // 非流动资产处置损失

SD_PROPERTY_ASSIGN_FLOAT totprofit; // 利润总额
SD_PROPERTY_ASSIGN_FLOAT incotaxexpe; // 所得税费用
SD_PROPERTY_ASSIGN_FLOAT netprofit; // 净利润
SD_PROPERTY_ASSIGN_FLOAT parenetp; // 归属于母公司所有者的净利润
SD_PROPERTY_ASSIGN_FLOAT minysharrigh; // 少数股东损益

SD_PROPERTY_ASSIGN_FLOAT basiceps; // 基本每股收益
SD_PROPERTY_ASSIGN_FLOAT dilutedeps; // 稀释每股收益

SD_PROPERTY_ASSIGN_FLOAT othercompinco; // 其他综合收益
SD_PROPERTY_ASSIGN_FLOAT parecompinco; // 归属于母公司所有者的其他综合收益
SD_PROPERTY_ASSIGN_FLOAT minysharinco; // 归属于少数股东的其他综合收益
SD_PROPERTY_ASSIGN_FLOAT compincoamt; // 综合收益总额
SD_PROPERTY_ASSIGN_FLOAT parecompincoamt; // 归属于母公司所有者的综合收益总额
SD_PROPERTY_ASSIGN_FLOAT minysharincoamt; // 归属于少数股东的综合收益总额

- (CGFloat)bizincorate; // 营业收入 / 营业总收入
- (CGFloat)bizincopermonth; // 一个月的营业收入

- (CGFloat)grossprofit; // 毛利润
- (CGFloat)rmtaxinteprofit; // 息税前利润
- (CGFloat)rmlosgainperprofit; // 扣除经常性损益营业利润

- (CGFloat)salmanexpes; // 销售费用和管理费用总和
- (CGFloat)salmanfinexpes; // 三费 = 销售费用 + 管理费用 + 正数的财务费用
- (CGFloat)salmanfinexpes_gross_rate; // 三费 / 毛利润

- (CGFloat)unoftenlosgain; // 非经常性损益净额
- (CGFloat)noninoutnet; // 营业外收支净额

@end
