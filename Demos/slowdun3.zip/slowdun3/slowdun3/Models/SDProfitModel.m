//
//  SDProfitModel.m
//  slowdun3
//
//  Created by Jymn_Chen on 2018/3/19.
//  Copyright © 2018年 com.slowdun3. All rights reserved.
//

#import "SDProfitModel.h"
#import "SDMathUtil.h"

@implementation SDProfitModel

// 营业收入 / 营业总收入
- (CGFloat)bizincorate {
    return [SDMathUtil safeDivide:self.bizinco to:self.biztotinco];
}

// 一个月的营业收入
- (CGFloat)bizincopermonth {
    return self.bizinco / 12.f;
}

// 毛利润
- (CGFloat)grossprofit {
    return self.bizinco - self.bizcost;
}

// 息税前利润
- (CGFloat)rmtaxinteprofit {
    return self.biztotinco - self.biztotcost + self.inteexpe;
}

// 扣除经常性损益营业利润
- (CGFloat)rmlosgainperprofit {
    return self.biztotinco - self.biztotcost;
}

// 销售费用和管理费用总和
- (CGFloat)salmanexpes {
    return self.salesexpe + self.manaexpe;
}

// 三费 = 销售费用 + 管理费用 + 正数的财务费用
- (CGFloat)salmanfinexpes {
    CGFloat expes = self.salesexpe + self.manaexpe;
    if (self.finexpe > 0) {
        expes += self.finexpe;
    }
    return expes;
}

// 三费 / 毛利润
- (CGFloat)salmanfinexpes_gross_rate {
    return [SDMathUtil safeDivide:self.salmanfinexpes to:self.grossprofit];
}

// 非经常性损益净额
- (CGFloat)unoftenlosgain {
    return self.perprofit - self.rmlosgainperprofit;
}

// 营业外收支净额
- (CGFloat)noninoutnet {
    return self.nonoreve - self.nonoexpe;
}

@end
