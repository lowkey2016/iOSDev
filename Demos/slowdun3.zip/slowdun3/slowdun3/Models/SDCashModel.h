//
//  SDCashModel.h
//  slowdun3
//
//  Created by Jymn_Chen on 2018/3/19.
//  Copyright © 2018年 com.slowdun3. All rights reserved.
//
//  现金流量表

#import "SDBaseModel.h"
#import "SDCommon.h"

@interface SDCashModel : SDBaseModel

SD_PROPERTY_COPY_STR begindate;
SD_PROPERTY_COPY_STR enddate;

SD_PROPERTY_ASSIGN_FLOAT laborgetcash; // 销售商品、提供劳务收到的现金
SD_PROPERTY_ASSIGN_FLOAT receotherbizcash; // 收到的其他与经营活动有关的现金
SD_PROPERTY_ASSIGN_FLOAT bizcashinfl; // 经营活动现金流入小计
SD_PROPERTY_ASSIGN_FLOAT labopayc; // 购买商品、接受劳务支付的现金
SD_PROPERTY_ASSIGN_FLOAT payworkcash; // 支付给职工以及为职工支付的现金
SD_PROPERTY_ASSIGN_FLOAT paytax; // 支付的各项税费
SD_PROPERTY_ASSIGN_FLOAT payacticash; // 支付的其他与经营活动有关的现金
SD_PROPERTY_ASSIGN_FLOAT bizcashoutf; // 经营活动现金流出小计
SD_PROPERTY_ASSIGN_FLOAT mananetr; // 经营活动产生的现金流量净额

SD_PROPERTY_ASSIGN_FLOAT withinvgetcash; // 收回投资所收到的现金
SD_PROPERTY_ASSIGN_FLOAT inveretugetcash; // 取得投资收益收到的现金
SD_PROPERTY_ASSIGN_FLOAT fixedassetnetc; // 处置固定资产、无形资产和其他长期资产所回收的现金净额
SD_PROPERTY_ASSIGN_FLOAT subsnetc; // 处置子公司及其他营业单位收到的现金净额
SD_PROPERTY_ASSIGN_FLOAT receinvcash; // 收到的其他与投资活动有关的现金
SD_PROPERTY_ASSIGN_FLOAT reducashpled; // 减少质押和定期存款所收到的现金
SD_PROPERTY_ASSIGN_FLOAT invcashinfl; // 投资活动现金流入小计
SD_PROPERTY_ASSIGN_FLOAT acquassetcash; // 购建固定资产、无形资产和其他长期资产所支付的现金
SD_PROPERTY_ASSIGN_FLOAT invpayc; // 投资所支付的现金
SD_PROPERTY_ASSIGN_FLOAT loannetr; // 质押贷款净增加额
SD_PROPERTY_ASSIGN_FLOAT subspaynetcash; // 取得子公司及其他营业单位支付的现金净额
SD_PROPERTY_ASSIGN_FLOAT payinvecash; // 支付的其他与投资活动有关的现金
SD_PROPERTY_ASSIGN_FLOAT incrcashpled; // 增加质押和定期存款所支付的现金
SD_PROPERTY_ASSIGN_FLOAT invcashoutf; // 投资活动现金流出小计
SD_PROPERTY_ASSIGN_FLOAT invnetcashflow; // 投资活动产生的现金流量净额

SD_PROPERTY_ASSIGN_FLOAT invrececash; // 吸收投资收到的现金
SD_PROPERTY_ASSIGN_FLOAT subsrececash; // 其中：子公司吸收少数股东投资收到的现金
SD_PROPERTY_ASSIGN_FLOAT recefromloan; // 取得借款收到的现金
SD_PROPERTY_ASSIGN_FLOAT issbdrececash; // 发行债券收到的现金
SD_PROPERTY_ASSIGN_FLOAT recefincash; // 收到其他与筹资活动有关的现金
SD_PROPERTY_ASSIGN_FLOAT fincashinfl; // 筹资活动现金流入小计
SD_PROPERTY_ASSIGN_FLOAT debtpaycash; // 偿还债务支付的现金
SD_PROPERTY_ASSIGN_FLOAT diviprofpaycash; // 分配股利、利润或偿付利息所支付的现金
SD_PROPERTY_ASSIGN_FLOAT subspaydivid; // 其中：子公司支付给少数股东的股利，利润
SD_PROPERTY_ASSIGN_FLOAT finrelacash; // 支付其他与筹资活动有关的现金
SD_PROPERTY_ASSIGN_FLOAT fincashoutf; // 筹资活动现金流出小计
SD_PROPERTY_ASSIGN_FLOAT finnetcflow; // 筹资活动产生的现金流量净额

SD_PROPERTY_ASSIGN_FLOAT chgexchgchgs; // 汇率变动对现金及现金等价物的影响
SD_PROPERTY_ASSIGN_FLOAT cashnetr; // 现金及现金等价物净增加额
SD_PROPERTY_ASSIGN_FLOAT inicashbala; // 期初现金及现金等价物余额
SD_PROPERTY_ASSIGN_FLOAT finalcashbala; // 期末现金及现金等价物余额

SD_PROPERTY_ASSIGN_FLOAT netprofit; // 净利润
SD_PROPERTY_ASSIGN_FLOAT minysharrigh; // 少数股东权益
SD_PROPERTY_ASSIGN_FLOAT unreinveloss; // 未确认的投资损失
SD_PROPERTY_ASSIGN_FLOAT asseimpa; // 资产减值准备
SD_PROPERTY_ASSIGN_FLOAT assedepr; // 固定资产折旧、油气资产折耗、生产性物资折旧
SD_PROPERTY_ASSIGN_FLOAT realestadep; // 投资性房地产折旧、摊销
SD_PROPERTY_ASSIGN_FLOAT intaasseamor; // 无形资产摊销
SD_PROPERTY_ASSIGN_FLOAT longdefeexpenamor; // 长期待摊费用摊销
SD_PROPERTY_ASSIGN_FLOAT prepexpedecr; // 待摊费用的减少
SD_PROPERTY_ASSIGN_FLOAT accrexpeincr; // 预提费用的增加
SD_PROPERTY_ASSIGN_FLOAT dispfixedassetloss; // 处置固定资产、无形资产和其他长期资产的损失
SD_PROPERTY_ASSIGN_FLOAT fixedassescraloss; // 固定资产报废损失
SD_PROPERTY_ASSIGN_FLOAT valuechgloss; // 公允价值变动损失
SD_PROPERTY_ASSIGN_FLOAT defeincoincr; // 递延收益增加（减：减少）
SD_PROPERTY_ASSIGN_FLOAT estidebts; // 预计负债
SD_PROPERTY_ASSIGN_FLOAT finexpe; // 财务费用
SD_PROPERTY_ASSIGN_FLOAT inveloss; // 投资损失
SD_PROPERTY_ASSIGN_FLOAT defetaxassetdecr; // 递延所得税资产减少
SD_PROPERTY_ASSIGN_FLOAT defetaxliabincr; // 递延所得税负债增加
SD_PROPERTY_ASSIGN_FLOAT inveredu; // 存货的减少
SD_PROPERTY_ASSIGN_FLOAT receredu; // 经营性应收项目的减少
SD_PROPERTY_ASSIGN_FLOAT payaincr; // 经营性应付项目的增加
SD_PROPERTY_ASSIGN_FLOAT unseparachg; // 已完工尚未结算款的减少(减:增加)
SD_PROPERTY_ASSIGN_FLOAT unfiparachg; // 已结算尚未完工款的增加(减:减少)
SD_PROPERTY_ASSIGN_FLOAT other; // 其他
SD_PROPERTY_ASSIGN_FLOAT biznetcflow; // 经营活动产生现金流量净额
SD_PROPERTY_ASSIGN_FLOAT debtintocapi; // 债务转为资本
SD_PROPERTY_ASSIGN_FLOAT expiconvbd; // 一年内到期的可转换公司债券
SD_PROPERTY_ASSIGN_FLOAT finfixedasset; // 融资租入固定资产
SD_PROPERTY_ASSIGN_FLOAT cashfinalbala; // 现金的期末余额
SD_PROPERTY_ASSIGN_FLOAT cashopenbala; // 现金的期初余额
SD_PROPERTY_ASSIGN_FLOAT equfinalbala; // 现金等价物的期末余额
SD_PROPERTY_ASSIGN_FLOAT equopenbala; // 现金等价物的期初余额
SD_PROPERTY_ASSIGN_FLOAT cashneti; // 现金及现金等价物的净增加额

// 间接法编制的现金流量表中的折旧摊销总和
- (CGFloat)depamortot;

// 资本支出 = 购建固定资产、无形资产和其他长期资产所支付的现金 + 取得子公司及其他营业单位支付的现金净额
- (CGFloat)capitalexp;

// 简化的自由现金流 v1 = 经营现金流净额 - 投资活动现金流出净额
- (CGFloat)simfreecashflowV1;

// 简化的自由现金流 v2 = 经营现金流净额 - 资本支出
- (CGFloat)simfreecashflowV2;

@end
