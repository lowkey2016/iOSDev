//
//  SDConfStockModel.h
//  slowdun3
//
//  Created by Jymn_Chen on 2018/3/25.
//  Copyright © 2018年 com.slowdun3. All rights reserved.
//

#import "SDBaseModel.h"
#import "SDCommon.h"

@interface SDConfStockModel : SDBaseModel

SD_PROPERTY_COPY_STR symbol;
SD_PROPERTY_COPY_STR name;

@end
