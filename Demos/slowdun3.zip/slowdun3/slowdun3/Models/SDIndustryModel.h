//
//  SDIndustryModel.h
//  slowdun3
//
//  Created by Jymn_Chen on 2018/3/20.
//  Copyright © 2018年 com.slowdun3. All rights reserved.
//
//  细分行业

#import "SDBaseModel.h"
#import "SDCommon.h"

@interface SDIndustryModel : SDBaseModel

SD_PROPERTY_COPY_STR name; // 行业名称
SD_PROPERTY_ASSIGN_BOOL isfin; // 是否金融行业

- (instancetype)initWithName:(NSString *)name isFin:(BOOL)isFin;

@end
