//
//  SDStockModel.h
//  slowdun3
//
//  Created by Jymn_Chen on 2018/3/19.
//  Copyright © 2018年 com.slowdun3. All rights reserved.
//
//  股票

#import "SDBaseModel.h"
#import "SDCommon.h"

#import "SDAssetModel.h"
#import "SDProfitModel.h"
#import "SDCashModel.h"
#import "SDBonusModel.h"
#import "SDQuoteModel.h"
#import "SDManualModel.h"
#import "SDMixModel.h"
#import "SDIndustryModel.h"

@interface SDStockModel : SDBaseModel

SD_PROPERTY_COPY_STR name; // 股票名称
SD_PROPERTY_COPY_STR symbol; // 股票代号
SD_PROPERTY_STRONG SDIndustryModel *industry; // 所属行业
SD_PROPERTY_COPY NSArray<NSNumber *> *years; // 支持的所有年份
SD_PROPERTY_COPY NSDictionary<NSNumber *, SDAssetModel *> *assets; // key: 年份, value: 资产负债表
SD_PROPERTY_COPY NSDictionary<NSNumber *, SDProfitModel *> *profits; // key: 年份, value: 利润表
SD_PROPERTY_COPY NSDictionary<NSNumber *, SDCashModel *> *cashes; // key: 年份, value: 现金流量表
SD_PROPERTY_COPY NSDictionary<NSNumber *, SDBonusModel *> *bonuses; // key: 年份, value: 分红送配
SD_PROPERTY_COPY NSDictionary<NSNumber *, SDManualModel *> *manuals; // key: 年份, value: 人工录入的数据
SD_PROPERTY_COPY NSDictionary<NSNumber *, SDMixModel *> *mixes; // key: 年份, value: 混合数据
SD_PROPERTY_STRONG SDQuoteModel *quote; // 最新市场数据

@end
