//
//  SDStockModel.h
//  slowdun3
//
//  Created by Jymn_Chen on 2018/3/19.
//  Copyright © 2018年 com.slowdun3. All rights reserved.
//
//  股票

#import "SDBaseModel.h"
#import "SDCommon.h"

#import "SDAssetModel.h"
#import "SDProfitModel.h"
#import "SDCashModel.h"
#import "SDBonusModel.h"
#import "SDQuoteModel.h"
#import "SDManualModel.h"
#import "SDMixModel.h"
#import "SDIndustryModel.h"

@interface SDStockModel : SDBaseModel

SD_PROPERTY_COPY_STR name; // 股票名称
SD_PROPERTY_COPY_STR symbol; // 股票代号
SD_PROPERTY_ASSIGN_INT32 expectedYearFrom; // 期望的起始年份
SD_PROPERTY_ASSIGN_INT32 expectedYearTo; // 期望的结束年份
SD_PROPERTY_STRONG SDIndustryModel *industry; // 所属行业
SD_PROPERTY_COPY NSArray<NSNumber *> *supportedYears; // 实际支持的所有年份，从最近年份开始排序，例如: 2018, 2017, 2016, ...
SD_PROPERTY_COPY NSDictionary<NSNumber *, SDAssetModel *> *assets; // key: 年份, value: 资产负债表
SD_PROPERTY_COPY NSDictionary<NSNumber *, SDProfitModel *> *profits; // key: 年份, value: 利润表
SD_PROPERTY_COPY NSDictionary<NSNumber *, SDCashModel *> *cashes; // key: 年份, value: 现金流量表
SD_PROPERTY_COPY NSDictionary<NSNumber *, SDBonusModel *> *bonuses; // key: 分红公告日期, value: 分红送配
SD_PROPERTY_COPY NSDictionary<NSNumber *, SDManualModel *> *manuals; // key: 年份, value: 人工录入的数据
SD_PROPERTY_COPY NSDictionary<NSNumber *, SDMixModel *> *mixes; // key: 年份, value: 混合数据
SD_PROPERTY_STRONG SDQuoteModel *quote; // 最新市场数据

- (instancetype)initWithName:(NSString *)name symbol:(NSString *)symbol yearFrom:(int32_t)yearFrom yearTo:(int32_t)yearTo industry:(SDIndustryModel *)industry;

@end
