//
//  SDBaseModel.h
//  slowdun3
//
//  Created by Jymn_Chen on 2018/3/19.
//  Copyright © 2018年 com.slowdun3. All rights reserved.
//
//  Model 基类

#import <Foundation/Foundation.h>

@interface SDBaseModel : NSObject

@end
