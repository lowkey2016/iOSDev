//
//  SDConfigModel.h
//  slowdun3
//
//  Created by Jymn_Chen on 2018/3/25.
//  Copyright © 2018年 com.slowdun3. All rights reserved.
//

#import "SDBaseModel.h"
#import "SDCommon.h"

@interface SDConfigModel : SDBaseModel

SD_PROPERTY_ASSIGN_INT32 yearFrom;
SD_PROPERTY_ASSIGN_INT32 yearTo;

@end
