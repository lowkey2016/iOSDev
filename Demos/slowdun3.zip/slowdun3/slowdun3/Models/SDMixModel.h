//
//  SDMixModel.h
//  slowdun3
//
//  Created by Jymn_Chen on 2018/3/19.
//  Copyright © 2018年 com.slowdun3. All rights reserved.
//
//  混合数据

#import "SDBaseModel.h"
#import "SDCommon.h"

@interface SDMixModel : SDBaseModel

SD_PROPERTY_ASSIGN_INT32 year; // 年份

SD_PROPERTY_ASSIGN_FLOAT shareprofit; // 股东利润 = 报告利润 A (归属于母公司所有者净利润) + 折扣、摊销与其它成本 B - 维持公司长期竞争地位的资本支出 C

// 是否小投入大产出参数
SD_PROPERTY_ASSIGN_FLOAT curprof_div_lstcapexp; // 当年的扣除非经常性损益营业利润 / 去年的资本支出
SD_PROPERTY_ASSIGN_FLOAT profchg_div_lstcapexp; // (当年扣除非经常性损益营业利润 - 去年扣除非经常性损益营业利润) / 去年的资本支出
SD_PROPERTY_ASSIGN_FLOAT profchg_div_lstrigchg; // (当年扣除非经常性损益营业利润 - 去年扣除非经常性损益营业利润) / (去年的股东权益 - 前年的股东权益)

// 留存利润使用效率
SD_PROPERTY_ASSIGN_FLOAT profsum_div_righin_3y; // 累计归属于母公司所有者净利润 / 投入的股东权益 = ( 税后归母净利润Y1 + 税后归母净利润Y1+1 + … + 税后归母净利润Y2 ) / ( 股东权益Y2 - 股东权益Y1 )，每 3 年一个周期
SD_PROPERTY_ASSIGN_FLOAT profsum_div_stayprof_3y; // 累计归属于母公司所有者净利润 / 留存利润 = ( 税后归母净利润Y1 + 税后归母净利润Y1+1 + … + 税后归母净利润Y2 ) / ( 留存利润Y2 - 留存利润Y1 )，每 3 年一个周期

// ROE 和 ROA
SD_PROPERTY_ASSIGN_FLOAT roe_this; // 本期 ROE = 归属于母公司所有者净利润 / 上期净资产
SD_PROPERTY_ASSIGN_FLOAT roe_ave; // 加权平均净资产收益率 ROE = 归属于母公司所有者净利润 / 平均净资产
SD_PROPERTY_ASSIGN_FLOAT roa_this; // 本期 ROA = 归属于母公司所有者净利润 / 上期总资产
SD_PROPERTY_ASSIGN_FLOAT roa_ave; // 加权平均总资产收益率 ROA = 归属于母公司所有者净利润 / 平均总资产
SD_PROPERTY_ASSIGN_FLOAT roe_sp_this; // 股东利润本期 ROE = 股东利润 / 上期净资产
SD_PROPERTY_ASSIGN_FLOAT roe_sp_ave; // 股东利润加权平均 ROE = 股东利润 / 平均净资产
SD_PROPERTY_ASSIGN_FLOAT roa_sp_this; // 股东利润本期 ROA = 股东利润 / 上期总资产
SD_PROPERTY_ASSIGN_FLOAT roa_sp_ave; // 股东利润加权平均 ROA = 股东利润 / 平均总资产

// 现金回收率
SD_PROPERTY_ASSIGN_FLOAT coe_ave; // 加权平均净资产现金回收率 = 经营现金流净额 / 平均净资产
SD_PROPERTY_ASSIGN_FLOAT coa_ave; // 加权平均总资产现金回收率 = 经营现金流净额 / 平均总资产

//// ROIC = NOPLAT / IC
//// NOPLAT = (主营业务税前净利润 = 营业利润 - 非经常性损益 - 超额现金收益 + 债主利润) * (1 - 税率)
//// IC = 年初的 股东权益 + 融资性负债（也可以称之为债主权益） + 一年内到期的非流动负债（将其全部看成有息负债，IC 算多不算少） - 超额现金（不需要用于日常运营的现金及现金等价物） - 投资相关资产 - 非主营业务的生产相关资产 - 其它资产
//// 其中：
//// 年初的超额现金 = 货币资金 + 增加的预收款合计 / 12 - (经营活动现金流出 + 资本支出) / 12
//// 非主营业务的生产相关资产 = 生物相关资产 + 油气资产 + 和主营业务无关的无形资产 + 待摊费用合计 + 递延所得税资产
//SD_PROPERTY_ASSIGN_FLOAT noplat;
//SD_PROPERTY_ASSIGN_FLOAT ic;
//SD_PROPERTY_ASSIGN_FLOAT freecurfds_lst;
//SD_PROPERTY_ASSIGN_FLOAT curfds_lst;
//SD_PROPERTY_ASSIGN_FLOAT roic;
//
//// NOPLAT_shareprofit = NOPLAT + 折扣、摊销与其它成本 - 维持公司长期竞争地位的资本支出
//// 股东利润 ROIC = NOPLAT_sp / IC
//SD_PROPERTY_ASSIGN_FLOAT roic_sp;

// 周转率相关
SD_PROPERTY_ASSIGN_FLOAT inve_torate; // 存货周转率
SD_PROPERTY_ASSIGN_FLOAT inve_todays; // 存货周转天数
SD_PROPERTY_ASSIGN_FLOAT accorece_torate; // 应收账款周转率
SD_PROPERTY_ASSIGN_FLOAT accorece_todays; // 应收账款周转天数
SD_PROPERTY_ASSIGN_FLOAT accopaya_torate; // 应付账款周转率
SD_PROPERTY_ASSIGN_FLOAT accopaya_todays; // 应付账款周转天数
SD_PROPERTY_ASSIGN_FLOAT turnoverdays; // 资金周转周期 = 存货周转天数 + 应收账款周转天数 - 应付账款周转天数

// 资本支出 = 购建固定资产、无形资产和其他长期资产所支付的现金 + 取得子公司及其他营业单位支付的现金净额 + 财报中记录的开发支出
SD_PROPERTY_ASSIGN_FLOAT capitalexp;

// 简化的自由现金流 = 经营现金流净额 - 资本支出
SD_PROPERTY_ASSIGN_FLOAT simfreecashflow;

@end
