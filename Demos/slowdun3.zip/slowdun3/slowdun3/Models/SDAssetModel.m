//
//  SDAssetModel.m
//  slowdun3
//
//  Created by Jymn_Chen on 2018/3/19.
//  Copyright © 2018年 com.slowdun3. All rights reserved.
//

#import "SDAssetModel.h"
#import "SDMathUtil.h"

@implementation SDAssetModel

#pragma mark - Asset

// 经营相关资产总和
- (CGFloat)manageassetot {
    return self.rectot + self.prep + self.interece + self.dividrece + self.inve;
}

// 生产相关资产总和
- (CGFloat)prodassetot {
    // 生产相关资产包括：固定资产、在建工程、工程物资、无形资产、商誉、长期待摊费用和递延所得税资产（负债）等项目
    return self.fixedassenet + self.consprog + self.engimate + self.prodasse + self.comasse + self.hydrasset + self.intaasset + self.deveexpe + self.goodwill + self.prepexpe + self.logprepexpe + self.defetaxasset + self.defeincotaxliab;
}

// 投资相关资产
- (CGFloat)inveassetot {
    return self.tradfinasset + self.avaisellasse + self.holdinvedue + self.equiinve + self.otherlonginve + self.inveprop;
}

// 其它资产总和
- (CGFloat)otherasettot {
    return self.totasset - self.manageassetot - self.prodassetot - self.inveassetot;
}

// 应收款总和 = 各种带应收二字的款项总额（除了应收利息和应收股利） - 应收票据里的银行承兑汇票金额
- (CGFloat)rectot {
    return self.notesrece + self.accorece + self.otherrece + self.longrece - self.notesrece_bank;
}

// 非主业资产（非金融行业主要指投资相关资产和其它资产总和）
- (CGFloat)sideaset {
    return self.inveassetot + self.otherasettot;
}

// 速动资产
- (CGFloat)liquidaset {
    return self.totcurrasset - self.inve;
}

#pragma mark - Liab

// 融资性负债合计
- (CGFloat)finliabtot {
    return self.shorttermborr + self.longborr + self.shorttermbdspaya + self.bdspaya + self.intepaya;
}

// 经营性负债合计
- (CGFloat)manageliabtot {
    return self.notespaya + self.accopaya + self.advapaym + self.copeworkersal + self.otherpay + self.longpaya;
}

// 分配性负债合计
- (CGFloat)payliabtot {
    return self.taxespaya + self.divipaya;
}

// 其它负债合计
- (CGFloat)otherliabtot {
    return self.totliab - self.finliabtot - self.manageliabtot - self.payliabtot;
}

// 高息负债 = 短期借款 + 长期借款
- (CGFloat)highborrtot {
    return self.shorttermborr + self.longborr;
}

// 高息负债率 = 高息负债 / 总资产
- (CGFloat)highborrate {
    return [SDMathUtil safeDivide:self.highborrtot to:self.totasset];
}

// 货币资金高息负债覆盖率 = 货币资金 / 高息负债
- (CGFloat)curhighborrcover {
    return [SDMathUtil safeDivide:self.curfds to:self.highborrtot];
}

// 有息负债
- (CGFloat)borrtot {
    return self.finliabtot;
}

// 有息负债率 = 有息负债 / 总资产
- (CGFloat)borrate {
    return [SDMathUtil safeDivide:self.borrtot to:self.totasset];
}

// 货币资金有息负债覆盖率 = 货币资金 / 有息负债
- (CGFloat)curborrcover {
    return [SDMathUtil safeDivide:self.curfds to:self.borrtot];
}

#pragma mark - Righaggr

// 盈余公积 + 未分配利润
- (CGFloat)reseandundiprof {
    return self.rese + self.undiprof;
}

#pragma mark - Graham

// 清算价值 = (货币资金 + 交易性金融资产) + (应收票据 + 应收账款) * 0.8 + 存货 * 0.6 + (可供出售金融资产 + 持有至到期投资 + 投资性房地产) * 0.5 + (固定资产净额 + 在建工程 + 工程物资) * 0.15 - 总负债
- (CGFloat)liquidvalue {
    return (self.curfds + self.tradfinasset) + (self.notesrece + self.accorece) * 0.8 + self.inve * 0.6 + (self.avaisellasse + self.holdinvedue + self.inveprop) * 0.5 + (self.fixedassenet + self.consprog + self.engimate) * 0.15 - self.totliab;
}

// 流动资产价值 = 流动资产 - 总负债
- (CGFloat)curassetvalue {
    return self.totcurrasset - self.totliab;
}

// 现金资产价值 = 现金资产 - 总负债
- (CGFloat)curfdsvalue {
    return self.curfds - self.totliab;
}

@end
