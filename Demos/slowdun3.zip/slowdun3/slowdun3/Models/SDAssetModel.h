//
//  SDAssetModel.h
//  slowdun3
//
//  Created by Jymn_Chen on 2018/3/19.
//  Copyright © 2018年 com.slowdun3. All rights reserved.
//
//  资产负债表

#import "SDBaseModel.h"
#import "SDCommon.h"

@interface SDAssetModel : SDBaseModel

SD_PROPERTY_COPY_STR reportdate; // 报表日期
SD_PROPERTY_ASSIGN_FLOAT curfds; // 货币资金
SD_PROPERTY_ASSIGN_FLOAT tradfinasset; // 交易性金融资产
SD_PROPERTY_ASSIGN_FLOAT notesrece; // 应收票据
SD_PROPERTY_ASSIGN_FLOAT accorece; // 应收账款
SD_PROPERTY_ASSIGN_FLOAT prep; // 预付款项
SD_PROPERTY_ASSIGN_FLOAT interece; // 应收利息
SD_PROPERTY_ASSIGN_FLOAT dividrece; // 应收股利
SD_PROPERTY_ASSIGN_FLOAT otherrece; // 其他应收款
SD_PROPERTY_ASSIGN_FLOAT inve; // 存货
SD_PROPERTY_ASSIGN_FLOAT prepexpe; // 待摊费用
SD_PROPERTY_ASSIGN_FLOAT othercurrasse; // 其他流动资产
SD_PROPERTY_ASSIGN_FLOAT totcurrasset; // 流动资产合计
SD_PROPERTY_ASSIGN_FLOAT avaisellasse; // 可供出售金融资产
SD_PROPERTY_ASSIGN_FLOAT holdinvedue; // 持有至到期投资
SD_PROPERTY_ASSIGN_FLOAT longrece; // 长期应收款
SD_PROPERTY_ASSIGN_FLOAT equiinve; // 长期股权投资
SD_PROPERTY_ASSIGN_FLOAT otherlonginve; // 其他长期投资
SD_PROPERTY_ASSIGN_FLOAT inveprop; // 投资性房地产
SD_PROPERTY_ASSIGN_FLOAT fixedasseimmo; // 固定资产原值
SD_PROPERTY_ASSIGN_FLOAT accudepr; // 累计折旧
SD_PROPERTY_ASSIGN_FLOAT fixedassenetw; // 固定资产净值
SD_PROPERTY_ASSIGN_FLOAT fixedasseimpa; // 固定资产减值准备
SD_PROPERTY_ASSIGN_FLOAT fixedassenet; // 固定资产净额
SD_PROPERTY_ASSIGN_FLOAT consprog; // 在建工程
SD_PROPERTY_ASSIGN_FLOAT engimate; // 工程物资
SD_PROPERTY_ASSIGN_FLOAT prodasse; // 生产性生物资产
SD_PROPERTY_ASSIGN_FLOAT comasse; // 公益性生物资产
SD_PROPERTY_ASSIGN_FLOAT hydrasset; // 油气资产
SD_PROPERTY_ASSIGN_FLOAT intaasset; // 无形资产
SD_PROPERTY_ASSIGN_FLOAT deveexpe; // 开发支出
SD_PROPERTY_ASSIGN_FLOAT goodwill; // 商誉
SD_PROPERTY_ASSIGN_FLOAT logprepexpe; // 长期待摊费用
SD_PROPERTY_ASSIGN_FLOAT defetaxasset; // 递延所得税资产
SD_PROPERTY_ASSIGN_FLOAT othernoncasse; // 其他非流动资产
SD_PROPERTY_ASSIGN_FLOAT totalnoncassets; // 非流动资产合计
SD_PROPERTY_ASSIGN_FLOAT totasset; // 资产总计
SD_PROPERTY_ASSIGN_FLOAT shorttermborr; // 短期借款
SD_PROPERTY_ASSIGN_FLOAT tradfinliab; // 交易性金融负债
SD_PROPERTY_ASSIGN_FLOAT notespaya; // 应付票据
SD_PROPERTY_ASSIGN_FLOAT accopaya; // 应付账款
SD_PROPERTY_ASSIGN_FLOAT advapaym; // 预收款项
SD_PROPERTY_ASSIGN_FLOAT copeworkersal; // 应付职工薪酬
SD_PROPERTY_ASSIGN_FLOAT taxespaya; // 应交税费
SD_PROPERTY_ASSIGN_FLOAT intepaya; // 应付利息
SD_PROPERTY_ASSIGN_FLOAT divipaya; // 应付股利
SD_PROPERTY_ASSIGN_FLOAT otherpay; // 其他应付款
SD_PROPERTY_ASSIGN_FLOAT shorttermbdspaya; // 应付短期债券
SD_PROPERTY_ASSIGN_FLOAT duenoncliab; // 一年内到期的非流动负债
SD_PROPERTY_ASSIGN_FLOAT othercurreliabi; // 其他流动负债
SD_PROPERTY_ASSIGN_FLOAT totalcurrliab; // 流动负债合计
SD_PROPERTY_ASSIGN_FLOAT longborr; // 长期借款
SD_PROPERTY_ASSIGN_FLOAT bdspaya; // 应付债券
SD_PROPERTY_ASSIGN_FLOAT longpaya; // 长期应付款
SD_PROPERTY_ASSIGN_FLOAT specpaya; // 专项应付款
SD_PROPERTY_ASSIGN_FLOAT longdefeinco; // 长期递延收益
SD_PROPERTY_ASSIGN_FLOAT defeincotaxliab; // 递延所得税负债
SD_PROPERTY_ASSIGN_FLOAT othernoncliabi; // 其他非流动负债
SD_PROPERTY_ASSIGN_FLOAT totalnoncliab; // 非流动负债合计
SD_PROPERTY_ASSIGN_FLOAT totliab; // 负债合计
SD_PROPERTY_ASSIGN_FLOAT righaggr; // 所有者权益(或股东权益)合计
SD_PROPERTY_ASSIGN_FLOAT paidincapi; // 实收资本(或股本)
SD_PROPERTY_ASSIGN_FLOAT capisurp; // 资本公积
SD_PROPERTY_ASSIGN_FLOAT treastk; // 减：库存股
SD_PROPERTY_ASSIGN_FLOAT specrese; // 专项储备
SD_PROPERTY_ASSIGN_FLOAT rese; // 盈余公积
SD_PROPERTY_ASSIGN_FLOAT generiskrese; // 一般风险准备
SD_PROPERTY_ASSIGN_FLOAT unreinveloss; // 未确定的投资损失
SD_PROPERTY_ASSIGN_FLOAT undiprof; // 未分配利润
SD_PROPERTY_ASSIGN_FLOAT topaycashdivi; // 拟分配现金股利
SD_PROPERTY_ASSIGN_FLOAT curtrandiff; // 外币报表折算差额
SD_PROPERTY_ASSIGN_FLOAT paresharrigh; // 归属于母公司股东权益合计
SD_PROPERTY_ASSIGN_FLOAT minysharrigh; // 少数股东权益
SD_PROPERTY_ASSIGN_FLOAT totliabsharequi; // 负债和所有者权益

// 人工输入
SD_PROPERTY_ASSIGN_FLOAT notesrece_bank; // 应收票据中的银行承兑汇票
SD_PROPERTY_ASSIGN_FLOAT notesrece_business; // 应收票据中的商业承兑汇票
SD_PROPERTY_ASSIGN_FLOAT notesrece_other; // 应收票据中的其它部分

- (CGFloat)manageassetot; // 经营相关资产总和
- (CGFloat)prodassetot; // 生产相关资产总和
- (CGFloat)inveassetot; // 投资相关资产
- (CGFloat)otherasettot; // 其它资产总和
- (CGFloat)rectot; // 应收款总和 = 各种带应收二字的款项总额 - 应收票据里的银行承兑汇票金额
- (CGFloat)sideaset; // 非主业资产（非金融行业主要指投资相关资产和其它资产总和）
- (CGFloat)liquidaset; // 速动资产

- (CGFloat)finliabtot; // 融资性负债合计
- (CGFloat)manageliabtot; // 经营性负债合计
- (CGFloat)payliabtot; // 分配性负债合计
- (CGFloat)otherliabtot; // 其它负债合计

- (CGFloat)highborrtot; // 高息负债 = 短期借款 + 长期借款
- (CGFloat)highborrate; // 高息负债率 = 高息负债 / 总资产
- (CGFloat)curhighborrcover; // 货币资金高息负债覆盖率 = 货币资金 / 高息负债
- (CGFloat)borrtot; // 有息负债
- (CGFloat)borrate; // 有息负债率 = 有息负债 / 总资产
- (CGFloat)curborrcover; // 货币资金有息负债覆盖率 = 货币资金 / 有息负债

- (CGFloat)reseandundiprof; // 盈余公积 + 未分配利润

// 格雷厄姆相关指标
- (CGFloat)liquidvalue; // 清算价值 = (货币资金 + 交易性金融资产) + (应收票据 + 应收账款) * 0.8 + 存货 * 0.6 + (可供出售金融资产 + 持有至到期投资 + 投资性房地产) * 0.5 + (固定资产净额 + 在建工程 + 工程物资) * 0.15 - 总负债
- (CGFloat)curassetvalue; // 流动资产价值 = 流动资产 - 总负债
- (CGFloat)curfdsvalue; // 现金资产价值 = 现金资产 - 总负债

@end
