//
//  SDIndustryModel.m
//  slowdun3
//
//  Created by Jymn_Chen on 2018/3/20.
//  Copyright © 2018年 com.slowdun3. All rights reserved.
//

#import "SDIndustryModel.h"

@implementation SDIndustryModel

#pragma mark - Init

- (instancetype)initWithName:(NSString *)name isFin:(BOOL)isFin {
    self = [super init];
    if (self) {
        _name = name;
        _isfin = isFin;
    }
    return self;
}

@end
