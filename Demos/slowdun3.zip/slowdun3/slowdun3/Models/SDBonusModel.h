//
//  SDBonusModel.h
//  slowdun3
//
//  Created by Jymn_Chen on 2018/3/19.
//  Copyright © 2018年 com.slowdun3. All rights reserved.
//
//  分红送配

#import "SDBaseModel.h"
#import "SDCommon.h"

@interface SDBonusModel : SDBaseModel

SD_PROPERTY_COPY_STR bonusimpdate; // 分红公告日期
SD_PROPERTY_COPY_STR bonusyear; // 分红实施年度
SD_PROPERTY_COPY_STR cur; // 货币单位
SD_PROPERTY_COPY_STR bonusskratio; // 送股比例（10送X）
SD_PROPERTY_COPY_STR tranaddskraio; // 转增股比例（10转增X）
SD_PROPERTY_COPY_STR recorddate; // 股权登记日
SD_PROPERTY_COPY_STR exrightdate; // 除权除息日

SD_PROPERTY_ASSIGN_FLOAT taxcdividend; // 税前红利（元）
SD_PROPERTY_ASSIGN_FLOAT taxfdividendbh; // 税前红利（美元）

SD_PROPERTY_COPY_STR tranaddsklistdate; // 转增股上市日
SD_PROPERTY_COPY_STR bonussklistdate; // 送股上市日
SD_PROPERTY_COPY_STR tranaddskaccday; // 转增股到账日
SD_PROPERTY_COPY_STR bonusskaccday; // 送股到账日
SD_PROPERTY_COPY_STR summarize; // 简介，例如 10派10送3

@end
