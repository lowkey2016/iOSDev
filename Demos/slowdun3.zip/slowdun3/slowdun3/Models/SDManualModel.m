//
//  SDManualModel.m
//  slowdun3
//
//  Created by Jymn_Chen on 2018/3/19.
//  Copyright © 2018年 com.slowdun3. All rights reserved.
//

#import "SDManualModel.h"
#import "SDMathUtil.h"

@implementation SDManualModel

// 应收账款之和
- (CGFloat)accorecetot {
    return self.accorece_credit_tot + self.accorece_single_tot + self.accorece_single_imp_tot;
}

// 应收账款坏账计提总额
- (CGFloat)accorece_bad_tot {
    return self.accorece_credit_bad + self.accorece_single_bad + self.accorece_single_imp_bad;
}

// 应收账款坏账计提比例
- (CGFloat)accorece_bad_rate {
    return [SDMathUtil safeDivide:self.accorece_bad_tot to:self.accorecetot];
}

// 产、销、存量之和
- (CGFloat)inve_prodsalesave {
    return self.inve_prod + self.inve_sale + self.inve_save;
}

// 产量和存量之和
- (CGFloat)inve_prodandsave {
    return self.inve_prod + self.inve_save;
}

@end
