//
//  SDCashModel.m
//  slowdun3
//
//  Created by Jymn_Chen on 2018/3/19.
//  Copyright © 2018年 com.slowdun3. All rights reserved.
//

#import "SDCashModel.h"

@implementation SDCashModel

// 间接法编制的现金流量表中的折旧摊销总和
- (CGFloat)depamortot {
    return self.assedepr + self.intaasseamor;
}

@end
