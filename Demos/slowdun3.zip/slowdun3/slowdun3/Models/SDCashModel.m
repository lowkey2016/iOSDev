//
//  SDCashModel.m
//  slowdun3
//
//  Created by Jymn_Chen on 2018/3/19.
//  Copyright © 2018年 com.slowdun3. All rights reserved.
//

#import "SDCashModel.h"

@implementation SDCashModel

// 间接法编制的现金流量表中的折旧摊销总和
- (CGFloat)depamortot {
    return self.assedepr + self.intaasseamor;
}

// 资本支出 = 购建固定资产、无形资产和其他长期资产所支付的现金 + 取得子公司及其他营业单位支付的现金净额
- (CGFloat)capitalexp {
    return self.acquassetcash + self.subspaynetcash;
}

// 简化的自由现金流 v1 = 经营现金流净额 - 投资活动现金流出净额
- (CGFloat)simfreecashflowV1 {
    return self.mananetr - self.invcashoutf;
}

// 简化的自由现金流 v2 = 经营现金流净额 - 资本支出
- (CGFloat)simfreecashflowV2 {
    return self.mananetr - self.capitalexp;
}

@end
