//
//  SDModelsTest.m
//  slowdun3
//
//  Created by Jymn_Chen on 2018/3/25.
//  Copyright © 2018年 com.slowdun3. All rights reserved.
//

#import "SDModelsTest.h"
#import "SDAssetModel.h"
#import "SDProfitModel.h"
#import "SDCashModel.h"
#import "SDQuoteModel.h"
#import "SDBonusModel.h"
#import "SDManualModel.h"
#import "YYModel.h"

@interface SDModelsTest ()

@end

@implementation SDModelsTest

- (void)start {
    [self test_ParseAssetModel];
    [self test_ParseProfitModel];
    [self test_ParseCashModel];
    [self test_ParseQuoteModel];
    [self test_ParseBonusModel];
    [self test_ParseManualModel];
}

- (void)test_ParseAssetModel {
    SDAssetModel *asset = [SDAssetModel yy_modelWithDictionary:[self loadJSONDictionary:@"zcfzb"]];
    SDAssertIsClass(asset, [SDAssetModel class]);
    SDAssertStrEq(asset.reportdate, @"20161231");
    SDAssertFloatEq(asset.curfds, 6.685496211822E10);
    SDAssertFloatEq(asset.tradfinasset, 0);
    SDAssertFloatEq(asset.notesrece, 8.17627172E8);
    SDAssertFloatEq(asset.accorece, 0);
    SDAssertFloatEq(asset.prep, 1.04610069692E9);
    SDAssertFloatEq(asset.interece, 1.4090485688E8);
    SDAssertFloatEq(asset.dividrece, 0);
    SDAssertFloatEq(asset.otherrece, 7.722756537E7);
    SDAssertFloatEq(asset.inve, 2.062225182555E10);
    SDAssertFloatEq(asset.prepexpe, 0);
    SDAssertFloatEq(asset.othercurrasse, 2.3147457063E8);
    SDAssertFloatEq(asset.totcurrasset, 9.018054880557E10);
    SDAssertFloatEq(asset.avaisellasse, 2.9E7);
    SDAssertFloatEq(asset.holdinvedue, 0);
    SDAssertFloatEq(asset.longrece, 0);
    SDAssertFloatEq(asset.equiinve, 0);
    SDAssertFloatEq(asset.otherlonginve, 0);
    SDAssertFloatEq(asset.inveprop, 0);
    SDAssertFloatEq(asset.fixedasseimmo, 1.897023552667E10);
    SDAssertFloatEq(asset.accudepr, 4.51502613204E9);
    SDAssertFloatEq(asset.fixedassenetw, 1.445520939463E10);
    SDAssertFloatEq(asset.fixedasseimpa, 2031955.29);
    SDAssertFloatEq(asset.fixedassenet, 1.445317743934E10);
    SDAssertFloatEq(asset.consprog, 2.74557999568E9);
    SDAssertFloatEq(asset.engimate, 0);
    SDAssertFloatEq(asset.prodasse, 0);
    SDAssertFloatEq(asset.comasse, 0);
    SDAssertFloatEq(asset.hydrasset, 0);
    SDAssertFloatEq(asset.intaasset, 3.5317406256E9);
    SDAssertFloatEq(asset.deveexpe, 0);
    SDAssertFloatEq(asset.goodwill, 0);
    SDAssertFloatEq(asset.logprepexpe, 1.8811877651E8);
    SDAssertFloatEq(asset.defetaxasset, 1.74553912068E9);
    SDAssertFloatEq(asset.othernoncasse, 0);
    SDAssertFloatEq(asset.totalnoncassets, 2.275398947484E10);
    SDAssertFloatEq(asset.totasset, 1.1293453828041E11);
    SDAssertFloatEq(asset.shorttermborr, 0);
    SDAssertFloatEq(asset.tradfinliab, 0);
    SDAssertFloatEq(asset.notespaya, 0);
    SDAssertFloatEq(asset.accopaya, 1.04060820318E9);
    SDAssertFloatEq(asset.advapaym, 1.754108223701E10);
    SDAssertFloatEq(asset.copeworkersal, 1.62850725203E9);
    SDAssertFloatEq(asset.taxespaya, 4.27228919457E9);
    SDAssertFloatEq(asset.intepaya, 3.448163533E7);
    SDAssertFloatEq(asset.divipaya, 0);
    SDAssertFloatEq(asset.otherpay, 1.72463857144E9);
    SDAssertFloatEq(asset.shorttermbdspaya, 0);
    SDAssertFloatEq(asset.duenoncliab, 0);
    SDAssertFloatEq(asset.othercurreliabi, 0);
    SDAssertFloatEq(asset.totalcurrliab, 3.702042542569E10);
    SDAssertFloatEq(asset.longborr, 0);
    SDAssertFloatEq(asset.bdspaya, 0);
    SDAssertFloatEq(asset.longpaya, 0);
    SDAssertFloatEq(asset.specpaya, 1.557E7);
    SDAssertFloatEq(asset.longdefeinco, 0);
    SDAssertFloatEq(asset.defeincotaxliab, 0);
    SDAssertFloatEq(asset.othernoncliabi, 0);
    SDAssertFloatEq(asset.totalnoncliab, 1.557E7);
    SDAssertFloatEq(asset.totliab, 3.703599542569E10);
    SDAssertFloatEq(asset.righaggr, 7.589854285472E10);
    SDAssertFloatEq(asset.paidincapi, 1.2561978E9);
    SDAssertFloatEq(asset.capisurp, 1.37496441572E9);
    SDAssertFloatEq(asset.treastk, 0);
    SDAssertFloatEq(asset.specrese, 0);
    SDAssertFloatEq(asset.rese, 7.13564996312E9);
    SDAssertFloatEq(asset.generiskrese, 4.2075840936E8);
    SDAssertFloatEq(asset.unreinveloss, 0);
    SDAssertFloatEq(asset.undiprof, 6.271780803661E10);
    SDAssertFloatEq(asset.topaycashdivi, 0);
    SDAssertFloatEq(asset.curtrandiff, 0);
    SDAssertFloatEq(asset.paresharrigh, 7.289413778325E10);
    SDAssertFloatEq(asset.minysharrigh, 3.00440507147E9);
    SDAssertFloatEq(asset.totliabsharequi, 1.1293453828041E11);
}

- (void)test_ParseProfitModel {
    SDProfitModel *profit = [SDProfitModel yy_modelWithJSON:[self loadJSONDictionary:@"gslrb"]];
    SDAssertStrEq(profit.begindate, @"20160101");
    SDAssertStrEq(profit.enddate, @"20161231");
    
    SDAssertFloatEq(profit.biztotinco, 4.015508441293E10);
    SDAssertFloatEq(profit.bizinco, 3.886218999384E10);
    SDAssertFloatEq(profit.inteinco, 1.29272290966E9);
    SDAssertFloatEq(profit.realsale, 0);
    SDAssertFloatEq(profit.otherbizinco, 0);
    
    SDAssertFloatEq(profit.biztotcost, 1.588945924351E10);
    SDAssertFloatEq(profit.bizcost, 3.41010408597E9);
    SDAssertFloatEq(profit.inteexpe, 1.2296104954E8);
    SDAssertFloatEq(profit.realsalecost, 0);
    SDAssertFloatEq(profit.deveexpe, 0);
    SDAssertFloatEq(profit.otherbizcost, 0);
    SDAssertFloatEq(profit.biztax, 6.50892634326E9);
    SDAssertFloatEq(profit.salesexpe, 1.6810520229E9);
    SDAssertFloatEq(profit.manaexpe, 4.18718984042E9);
    SDAssertFloatEq(profit.finexpe, -3.317518852E7);
    SDAssertFloatEq(profit.asseimpaloss, 1.232749622E7);
    
    SDAssertFloatEq(profit.valuechgloss, 0);
    SDAssertFloatEq(profit.inveinco, 0);
    SDAssertFloatEq(profit.assoinveprof, 0);
    SDAssertFloatEq(profit.exchggain, 0);
    SDAssertFloatEq(profit.otherbizprof, 0);
    
    SDAssertFloatEq(profit.perprofit, 2.426562516942E10);
    SDAssertFloatEq(profit.nonoreve, 8553926.06);
    SDAssertFloatEq(profit.nonoexpe, 3.1629813837E8);
    SDAssertFloatEq(profit.noncassetsdisl, 1960971.07);
    
    
    SDAssertFloatEq(profit.totprofit, 2.395788095711E10);
    SDAssertFloatEq(profit.incotaxexpe, 6.02723784723E9);
    SDAssertFloatEq(profit.netprofit, 1.793064310988E10);
    SDAssertFloatEq(profit.parenetp, 1.671836273416E10);
    SDAssertFloatEq(profit.minysharrigh, 1.21228037572E9);
    
    SDAssertFloatEq(profit.basiceps, 13.31);
    SDAssertFloatEq(profit.dilutedeps, 13.31);
    
    SDAssertFloatEq(profit.othercompinco, 1793233.91);
    SDAssertFloatEq(profit.parecompinco, 1793233.91);
    SDAssertFloatEq(profit.minysharinco, 0);
    SDAssertFloatEq(profit.compincoamt, 1.793243634379E10);
    SDAssertFloatEq(profit.parecompincoamt, 1.672015596807E10);
    SDAssertFloatEq(profit.minysharincoamt, 1.21228037572E9);
}

- (void)test_ParseCashModel {
    SDCashModel *cash = [SDCashModel yy_modelWithJSON:[self loadJSONDictionary:@"xjllb"]];
    SDAssertStrEq(cash.begindate, @"20160101");
    SDAssertStrEq(cash.enddate, @"20161231");
    
    SDAssertFloatEq(cash.laborgetcash, 6.101296410254E10);
    SDAssertFloatEq(cash.receotherbizcash, 1.8914272395E8);
    SDAssertFloatEq(cash.bizcashinfl, 6.727914563793E10);
    SDAssertFloatEq(cash.labopayc, 2.77302040327E9);
    SDAssertFloatEq(cash.payworkcash, 4.67415423666E9);
    SDAssertFloatEq(cash.paytax, 1.75105163312E10);
    SDAssertFloatEq(cash.payacticash, 2.37148677688E9);
    SDAssertFloatEq(cash.bizcashoutf, 2.982789599088E10);
    SDAssertFloatEq(cash.mananetr, 3.745124964705E10);
    
    SDAssertFloatEq(cash.withinvgetcash, 0);
    SDAssertFloatEq(cash.inveretugetcash, 0);
    SDAssertFloatEq(cash.fixedassetnetc, 92084.5);
    SDAssertFloatEq(cash.subsnetc, 0);
    SDAssertFloatEq(cash.receinvcash, 5562351.19);
    SDAssertFloatEq(cash.reducashpled, 0);
    SDAssertFloatEq(cash.invcashinfl, 5654435.69);
    SDAssertFloatEq(cash.acquassetcash, 1.01917813692E9);
    SDAssertFloatEq(cash.invpayc, 0);
    SDAssertFloatEq(cash.loannetr, 0);
    SDAssertFloatEq(cash.subspaynetcash, 0);
    SDAssertFloatEq(cash.payinvecash, 8.897710297E7);
    SDAssertFloatEq(cash.incrcashpled, 0);
    SDAssertFloatEq(cash.invcashoutf, 1.10815523989E9);
    SDAssertFloatEq(cash.invnetcashflow, -1.1025008042E9);
    
    SDAssertFloatEq(cash.invrececash, 1.6E7);
    SDAssertFloatEq(cash.subsrececash, 1.6E7);
    SDAssertFloatEq(cash.recefromloan, 0);
    SDAssertFloatEq(cash.issbdrececash, 0);
    SDAssertFloatEq(cash.recefincash, 0);
    SDAssertFloatEq(cash.fincashinfl, 1.6E7);
    SDAssertFloatEq(cash.debtpaycash, 0);
    SDAssertFloatEq(cash.diviprofpaycash, 8.35051225223E9);
    SDAssertFloatEq(cash.subspaydivid, 5.3206728655E8);
    SDAssertFloatEq(cash.finrelacash, 0);
    SDAssertFloatEq(cash.fincashoutf, 8.35051225223E9);
    SDAssertFloatEq(cash.finnetcflow, -8.33451225223E9);
    
    SDAssertFloatEq(cash.chgexchgchgs, 72317.8);
    SDAssertFloatEq(cash.cashnetr, 2.801430890842E10);
    SDAssertFloatEq(cash.inicashbala, 3.478048590457E10);
    SDAssertFloatEq(cash.finalcashbala, 6.279479481299E10);
    
    SDAssertFloatEq(cash.netprofit, 1.793064310988E10);
    SDAssertFloatEq(cash.minysharrigh, 0);
    SDAssertFloatEq(cash.unreinveloss, 0);
    SDAssertFloatEq(cash.asseimpa, 1.232749622E7);
    SDAssertFloatEq(cash.assedepr, 8.4272807204E8);
    SDAssertFloatEq(cash.realestadep, 0);
    SDAssertFloatEq(cash.intaasseamor, 8.045789599E7);
    SDAssertFloatEq(cash.longdefeexpenamor, 1.100870417E7);
    SDAssertFloatEq(cash.prepexpedecr, 0);
    SDAssertFloatEq(cash.accrexpeincr, 0);
    SDAssertFloatEq(cash.dispfixedassetloss, 0);
    SDAssertFloatEq(cash.fixedassescraloss, 1869869.13);
    SDAssertFloatEq(cash.valuechgloss, 0);
    SDAssertFloatEq(cash.defeincoincr, 0);
    SDAssertFloatEq(cash.estidebts, 0);
    SDAssertFloatEq(cash.finexpe, 0);
    SDAssertFloatEq(cash.inveloss, 0);
    SDAssertFloatEq(cash.defetaxassetdecr, -5.9020304654E8);
    SDAssertFloatEq(cash.defetaxliabincr, 0);
    SDAssertFloatEq(cash.inveredu, -2.60895480285E9);
    SDAssertFloatEq(cash.receredu, 7.66965056584E9);
    SDAssertFloatEq(cash.payaincr, 1.410172178317E10);
    SDAssertFloatEq(cash.unseparachg, 0);
    SDAssertFloatEq(cash.unfiparachg, 0);
    SDAssertFloatEq(cash.other, 0);
    SDAssertFloatEq(cash.biznetcflow, 3.745124964705E10);
    SDAssertFloatEq(cash.debtintocapi, 0);
    SDAssertFloatEq(cash.expiconvbd, 0);
    SDAssertFloatEq(cash.finfixedasset, 0);
    SDAssertFloatEq(cash.cashfinalbala, 6.279479481299E10);
    SDAssertFloatEq(cash.cashopenbala, 3.478048590457E10);
    SDAssertFloatEq(cash.equfinalbala, 0);
    SDAssertFloatEq(cash.equopenbala, 0);
    SDAssertFloatEq(cash.cashneti, 2.801430890842E10);
}

- (void)test_ParseQuoteModel {
    SDQuoteModel *quote = [SDQuoteModel yy_modelWithJSON:[self loadJSONDictionary:@"quote"]];
    SDAssertFloatEq(quote.current, 747.73);
    SDAssertFloatEq(quote.totalShares, 1256197800);
    SDAssertFloatEq(quote.float_shares, 1256197799);
    SDAssertFloatEq(quote.dividend, 6.79);
    
    SDAssertStrEq(quote.time, @"Tue Mar 20 14:59:59 +0800 2018");
    SDAssertStrEq(quote.currency_unit, @"CNY");
}

- (void)test_ParseBonusModel {
    SDBonusModel *bonus = [SDBonusModel yy_modelWithJSON:[self loadJSONDictionary:@"bonus"]];
    SDAssertStrEq(bonus.bonusimpdate, @"20170701");
    SDAssertStrEq(bonus.bonusyear, @"2016");
    SDAssertStrEq(bonus.cur, @"人民币");
    SDAssertNil(bonus.bonusskratio);
    SDAssertNil(bonus.tranaddskraio);
    SDAssertStrEq(bonus.recorddate, @"20170706");
    SDAssertStrEq(bonus.exrightdate, @"20170707");
    
    SDAssertFloatEq(bonus.taxcdividend, 67.87);
    SDAssertFloatEq(bonus.taxfdividendbh, 0.0);
    
    SDAssertNil(bonus.tranaddsklistdate);
    SDAssertNil(bonus.bonussklistdate);
    SDAssertNil(bonus.tranaddskaccday);
    SDAssertNil(bonus.bonusskaccday);
    SDAssertStrEq(bonus.summarize, @"10派67.87");
}

- (void)test_ParseManualModel {
#warning - TODO 补充人工输入数据的单元测试
//    SDManualModel *manual = [SDManualModel yy_modelWithJSON:[self loadJSONDictionary:@"fjsj"]];
}

#pragma mark - Common Methods

- (NSDictionary *)loadJSONDictionary:(NSString *)type {
    NSError *err;
    NSString *fileName = [NSString stringWithFormat:@"test_%@.json", type];
    NSString *filePath = [[NSBundle mainBundle] pathForResource:fileName ofType:nil];
    NSData *jsonData = [[NSData alloc] initWithContentsOfFile:filePath];
    NSDictionary *jsonDict = [NSJSONSerialization JSONObjectWithData:jsonData options:NSJSONReadingAllowFragments error:&err];
    NSAssert(jsonDict && !err, err.localizedDescription);
    return jsonDict;
}

@end
