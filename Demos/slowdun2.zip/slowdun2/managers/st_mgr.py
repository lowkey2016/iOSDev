# -*- coding: utf-8 -*-

import os
import sys
import re
from utils.util_res import ResUtil
from utils.util_req import ReqUtil
from utils.util_re import RegUtil
import json

class StMgr(object):
	def fetch_finforms_data_from_network(self, st_symbol):
		req = ReqUtil(st_symbol)
		html_content = req.prepare()
		if html_content is not None:
			desc = '<title>(.*?) '
			# print desc
			st_name = RegUtil.match_one_from_re(desc, html_content)
		else:
			st_name = ''
		# fname = 'test_html_%s' % st_name
		# file_path = ResUtil.get_file_path(fname)
		# with open(file_path, 'w') as outfile:
		# 	outfile.write(html_content)
		dirname = 'db/%s_%s' % (st_symbol, st_name)

		# 资产负债表
		content = req.fetch(ReqUtil.REP_TYPE_ASSETS)
		json_data = json.loads(content)
		file_path = ResUtil.get_zcfzb_file_path(dirname)
		with open(file_path, 'w') as outfile:
			json.dump(json_data, outfile)
		# print content

		# 利润表
		content = req.fetch(ReqUtil.REP_TYPE_PROFIT)
		json_data = json.loads(content)
		file_path = ResUtil.get_gslrb_file_path(dirname)
		with open(file_path, 'w') as outfile:
			json.dump(json_data, outfile)
		# print content

		# 现金流量表
		content = req.fetch(ReqUtil.REP_TYPE_CASH)
		json_data = json.loads(content)
		file_path = ResUtil.get_xjllb_file_path(dirname)
		with open(file_path, 'w') as outfile:
			json.dump(json_data, outfile)
		# print content

	def fetch_curdata_from_network(self, st_symbol):
		req = ReqUtil(st_symbol)
		html_content = req.prepare()
		if html_content is not None:
			desc = '<title>(.*?) '
			st_name = RegUtil.match_one_from_re(desc, html_content)
		else:
			st_name = ''
		dirname = 'db/%s_%s' % (st_symbol, st_name)

		# 最新数据
		content = req.fetch(ReqUtil.REP_TYPE_CUR)
		json_data = json.loads(content)
		file_path = ResUtil.get_quote_file_path(dirname)
		with open(file_path, 'w') as outfile:
			json.dump(json_data, outfile)
		# print content

	# 家电
	def fetch_jiadian_finforms_data_from_network(self):
		self.fetch_finforms_data_from_network('SZ000651') # 格力电器
		self.fetch_finforms_data_from_network('SZ000333') # 美的集团
		self.fetch_finforms_data_from_network('SH600690') # 青岛海尔

	def fetch_jiadian_curdata_from_network(self):
		self.fetch_curdata_from_network('SZ000651') # 格力电器
		self.fetch_curdata_from_network('SZ000333') # 美的集团
		self.fetch_curdata_from_network('SH600690') # 青岛海尔

	# 家电的厨电细分行业
	def fetch_jiadian_chudian_finforms_data_from_network(self):
		self.fetch_finforms_data_from_network('SZ002508') # 老板电器
		self.fetch_finforms_data_from_network('SZ002035') # 华帝股份
		self.fetch_finforms_data_from_network('SZ002543') # 万和电气
		self.fetch_finforms_data_from_network('SZ002032') # 苏泊尔
		self.fetch_finforms_data_from_network('SZ002242') # 九阳股份
		self.fetch_finforms_data_from_network('SZ002677') # 浙江美大
		self.fetch_finforms_data_from_network('SZ002403') # 爱仕达

	def fetch_jiadian_chudian_curdata_from_network(self):
		self.fetch_curdata_from_network('SZ002508') # 老板电器
		self.fetch_curdata_from_network('SZ002035') # 华帝股份
		self.fetch_curdata_from_network('SZ002543') # 万和电气
		self.fetch_curdata_from_network('SZ002032') # 苏泊尔
		self.fetch_curdata_from_network('SZ002242') # 九阳股份
		self.fetch_curdata_from_network('SZ002677') # 浙江美大
		self.fetch_curdata_from_network('SZ002403') # 爱仕达

	# 酿酒的白酒细分行业
	def fetch_niangjiu_baijiu_finforms_data_from_network(self):
		self.fetch_finforms_data_from_network('SH600519') # 贵州茅台
		self.fetch_finforms_data_from_network('SZ000858') # 五粮液
		self.fetch_finforms_data_from_network('SZ000568') # 泸州老窖
		self.fetch_finforms_data_from_network('SZ002304') # 洋河股份
		self.fetch_finforms_data_from_network('SH600702') # 沱牌舍得
		self.fetch_finforms_data_from_network('SZ000799') # 酒鬼酒
		self.fetch_finforms_data_from_network('SH603369') # 今世缘
		self.fetch_finforms_data_from_network('SZ000596') # 古井贡酒
		self.fetch_finforms_data_from_network('SH603589') # 口子窖
		self.fetch_finforms_data_from_network('SH600199') # 金种子酒
		self.fetch_finforms_data_from_network('SH603198') # 迎驾贡酒
		self.fetch_finforms_data_from_network('SH603919') # 金徽酒
		self.fetch_finforms_data_from_network('SH600197') # 伊力特
		
		# self.fetch_finforms_data_from_network('SH600238') # 海南椰岛
		# self.fetch_finforms_data_from_network('SH601579') # 会稽山
		# self.fetch_finforms_data_from_network('SH600809') # 山西汾酒
		# self.fetch_finforms_data_from_network('SH600779') # 水井坊
		# self.fetch_finforms_data_from_network('SH600365') # 通葡股份
		# self.fetch_finforms_data_from_network('SH603779') # 威龙股份
		# self.fetch_finforms_data_from_network('SH600573') # 惠泉啤酒
		# self.fetch_finforms_data_from_network('SZ002646') # 青青稞酒
		# self.fetch_finforms_data_from_network('SZ000729') # 燕京啤酒
		# self.fetch_finforms_data_from_network('SH600600') # 青岛啤酒
		# self.fetch_finforms_data_from_network('SZ000929') # 兰州黄河
		# self.fetch_finforms_data_from_network('SH600616') # 金枫酒业
		# self.fetch_finforms_data_from_network('SH600059') # 古越龙山
		# self.fetch_finforms_data_from_network('SZ002461') # 珠江啤酒
		# self.fetch_finforms_data_from_network('SH600132') # 重庆啤酒
		# self.fetch_finforms_data_from_network('SZ000869') # 张裕A

	def fetch_niangjiu_baijiu_curdata_from_network(self):
		self.fetch_curdata_from_network('SH600519') # 贵州茅台
		self.fetch_curdata_from_network('SZ000858') # 五粮液
		self.fetch_curdata_from_network('SZ000568') # 泸州老窖
		self.fetch_curdata_from_network('SZ002304') # 洋河股份
		self.fetch_curdata_from_network('SH600702') # 沱牌舍得
		self.fetch_curdata_from_network('SZ000799') # 酒鬼酒
		self.fetch_curdata_from_network('SH603369') # 今世缘
		self.fetch_curdata_from_network('SZ000596') # 古井贡酒
		self.fetch_curdata_from_network('SH603589') # 口子窖
		self.fetch_curdata_from_network('SH600199') # 金种子酒
		self.fetch_curdata_from_network('SH603198') # 迎驾贡酒
		self.fetch_curdata_from_network('SH603919') # 金徽酒
		self.fetch_curdata_from_network('SH600197') # 伊力特

		# self.fetch_curdata_from_network('SH600238') # 海南椰岛
		# self.fetch_curdata_from_network('SH601579') # 会稽山
		# self.fetch_curdata_from_network('SH600809') # 山西汾酒
		# self.fetch_curdata_from_network('SH600779') # 水井坊
		# self.fetch_curdata_from_network('SH600365') # 通葡股份
		# self.fetch_curdata_from_network('SH603779') # 威龙股份
		# self.fetch_curdata_from_network('SH600573') # 惠泉啤酒
		# self.fetch_curdata_from_network('SZ002646') # 青青稞酒
		# self.fetch_curdata_from_network('SZ000729') # 燕京啤酒
		# self.fetch_curdata_from_network('SH600600') # 青岛啤酒
		# self.fetch_curdata_from_network('SZ000929') # 兰州黄河
		# self.fetch_curdata_from_network('SH600616') # 金枫酒业
		# self.fetch_curdata_from_network('SH600059') # 古越龙山
		# self.fetch_curdata_from_network('SZ002461') # 珠江啤酒
		# self.fetch_curdata_from_network('SH600132') # 重庆啤酒
		# self.fetch_curdata_from_network('SZ000869') # 张裕A

	# 食品饮料的调味品细分行业
	def fetch_fooddrink_condiment_finforms_from_network(self):
		self.fetch_finforms_data_from_network('SH603288') # 海天味业
		self.fetch_finforms_data_from_network('SH603696') # 安记食品
		self.fetch_finforms_data_from_network('SZ002650') # 加加食品
		self.fetch_finforms_data_from_network('SH603027') # 千禾味业
		self.fetch_finforms_data_from_network('SH600872') # 中炬高新
		self.fetch_finforms_data_from_network('SH600305') # 恒顺醋业
		
	def fetch_fooddrink_condiment_curdata_from_network(self):
		self.fetch_curdata_from_network('SH603288') # 海天味业
		self.fetch_curdata_from_network('SH603696') # 安记食品
		self.fetch_curdata_from_network('SZ002650') # 加加食品
		self.fetch_curdata_from_network('SH603027') # 千禾味业
		self.fetch_curdata_from_network('SH600872') # 中炬高新
		self.fetch_curdata_from_network('SH600305') # 恒顺醋业

	# 房地产的 PPP 细分行业
	def fetch_fangdichan_ppp_finforms_data_from_network(self):
		self.fetch_finforms_data_from_network('SH600340') # 华夏幸福

	def fetch_fangdichan_ppp_curdata_from_network(self):
		self.fetch_curdata_from_network('SH600340') # 华夏幸福

	# 其它
	def fetch_others_finforms_from_network(self):
		self.fetch_finforms_data_from_network('SH600298') # 安琪酵母

	def fetch_others_curdata_from_network(self):
		self.fetch_curdata_from_network('SH600298') # 安琪酵母
