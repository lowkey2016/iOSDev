# -*- coding: utf-8 -*-

import os
import sys
import re
from utils.util_req import ReqUtil
from utils.util_re import RegUtil
from utils.util_file import FileUtil
import utils.util_cons as Cons
import json

class StMgr(object):
	def fetch_data_from_network(self, industry, st_symbol, cur_data_only=False):
		if not industry or len(industry) == 0:
			industry = Cons.INDUSTRY_UNKNOWN
		assert st_symbol and len(st_symbol) > 0

		# 创建目录
		dbpath = 'resources/db'
		fu = FileUtil(basedir=None)
		fu.create_dir(dpath=dbpath, force=False)
		fu.cd(dpath=dbpath)
		fu.create_dir(dpath=industry, force=False)
		fu.cd(dpath=industry)

		# 匹配股票名
		req = ReqUtil(st_symbol)
		html_content = req.prepare()
		if html_content is not None:
			desc = '<title>(.*?) '
			# print desc
			st_name = RegUtil.match_one_from_re(desc, html_content)
		else:
			st_name = '匹配失败'
		dirname = '%s_%s' % (st_symbol, st_name)
		fu.create_dir(dpath=dirname, force=False)
		fu.cd(dpath=dirname)

		# 保存 html 内容
		# fpath = '%s_mainpage.html' % st_name
		# fu.write_to_file(fpath=fpath, content=html_content)

		# 最新数据
		content = req.fetch(ReqUtil.REP_TYPE_CUR)
		# print content
		# json_data = json.loads(content)
		fpath = 'quote.json'
		fu.write_to_file(fpath=fpath, content=content)
		if cur_data_only:
			return

		# 资产负债表
		content = req.fetch(ReqUtil.REP_TYPE_ASSETS)
		# print content
		# json_data = json.loads(content)
		fpath = 'zcfzb.json'
		fu.write_to_file(fpath=fpath, content=content)
		
		# 利润表
		content = req.fetch(ReqUtil.REP_TYPE_PROFIT)
		# print content
		# json_data = json.loads(content)
		fpath = 'gslrb.json'
		fu.write_to_file(fpath=fpath, content=content)
		
		# 现金流量表
		content = req.fetch(ReqUtil.REP_TYPE_CASH)
		# print content
		# json_data = json.loads(content)
		fpath = 'xjllb.json'
		fu.write_to_file(fpath=fpath, content=content)

	# 家电行业
	def fetch_eletric_all_data_from_network(self, cur_data_only=False):
		symbols = []
		symbols.append('SZ000651') # 格力电器
		symbols.append('SZ000333') # 美的集团
		symbols.append('SH600690') # 青岛海尔

		industry = Cons.INDUSTRY_ELETRIC_ALL
		for st_symbol in symbols:
			self.fetch_data_from_network(industry=industry, st_symbol=st_symbol, cur_data_only=cur_data_only)

	# 家电的厨电细分行业
	def fetch_eletric_kitchen_data_from_network(self, cur_data_only=False):
		symbols = []
		symbols.append('SZ002508') # 老板电器
		symbols.append('SZ002035') # 华帝股份
		symbols.append('SZ002543') # 万和电气
		symbols.append('SZ002032') # 苏泊尔
		symbols.append('SZ002242') # 九阳股份
		symbols.append('SZ002677') # 浙江美大
		symbols.append('SZ002403') # 爱仕达

		industry = Cons.INDUSTRY_ELETRIC_KITCHEN
		for st_symbol in symbols:
			self.fetch_data_from_network(industry=industry, st_symbol=st_symbol, cur_data_only=cur_data_only)

	# 酿酒的白酒细分行业
	def fetch_vintage_spirit_data_from_network(self, cur_data_only=False):
		symbols = []
		symbols.append('SH600519') # 贵州茅台
		symbols.append('SZ000858') # 五粮液
		symbols.append('SZ000568') # 泸州老窖
		symbols.append('SZ002304') # 洋河股份
		symbols.append('SH600702') # 沱牌舍得
		symbols.append('SZ000799') # 酒鬼酒
		symbols.append('SH603369') # 今世缘
		symbols.append('SZ000596') # 古井贡酒
		symbols.append('SH603589') # 口子窖
		symbols.append('SH600199') # 金种子酒
		symbols.append('SH603198') # 迎驾贡酒
		symbols.append('SH603919') # 金徽酒
		symbols.append('SH600197') # 伊力特
		# symbols.append('SH600238') # 海南椰岛
		# symbols.append('SH601579') # 会稽山
		# symbols.append('SH600809') # 山西汾酒
		# symbols.append('SH600779') # 水井坊
		# symbols.append('SH600365') # 通葡股份
		# symbols.append('SH603779') # 威龙股份
		# symbols.append('SH600573') # 惠泉啤酒
		# symbols.append('SZ002646') # 青青稞酒
		# symbols.append('SZ000729') # 燕京啤酒
		# symbols.append('SH600600') # 青岛啤酒
		# symbols.append('SZ000929') # 兰州黄河
		# symbols.append('SH600616') # 金枫酒业
		# symbols.append('SH600059') # 古越龙山
		# symbols.append('SZ002461') # 珠江啤酒
		# symbols.append('SH600132') # 重庆啤酒
		# symbols.append('SZ000869') # 张裕A

		industry = Cons.INDUSTRY_VINTAGE_SPIRIT
		for st_symbol in symbols:
			self.fetch_data_from_network(industry=industry, st_symbol=st_symbol, cur_data_only=cur_data_only)

	# 食品饮料的调味品细分行业
	def fetch_fooddrink_condiment_data_from_network(self, cur_data_only=False):
		symbols = []
		symbols.append('SH603288') # 海天味业
		symbols.append('SH603696') # 安记食品
		symbols.append('SZ002650') # 加加食品
		symbols.append('SH603027') # 千禾味业
		symbols.append('SH600872') # 中炬高新
		symbols.append('SH600305') # 恒顺醋业

		industry = Cons.INDUSTRY_FOODDRINK_CONDIMENT
		for st_symbol in symbols:
			self.fetch_data_from_network(industry=industry, st_symbol=st_symbol, cur_data_only=cur_data_only)

	# 房地产行业
	def fetch_realestate_all_data_from_network(self, cur_data_only=False):
		symbols = []
		symbols.append('SZ000002') # 万科A
		symbols.append('SH600048') # 保利地产

		industry = Cons.INDUSTRY_REALESTATE_ALL
		for st_symbol in symbols:
			self.fetch_data_from_network(industry=industry, st_symbol=st_symbol, cur_data_only=cur_data_only)

	# 房地产的 PPP 细分行业
	def fetch_realestate_ppp_data_from_network(self, cur_data_only=False):
		symbols = []
		symbols.append('SH600340') # 华夏幸福
		symbols.append('SZ002146') # 荣盛发展

		industry = Cons.INDUSTRY_REALESTATE_PPP
		for st_symbol in symbols:
			self.fetch_data_from_network(industry=industry, st_symbol=st_symbol, cur_data_only=cur_data_only)

	# 中药行业
	def fetch_cn_medicine_all_from_network(self, cur_data_only=False):
		symbols = []
		symbols.append('SZ000423') # 东阿阿胶

		industry = Cons.INDUSTRY_CN_MEDICINE_ALL
		for st_symbol in symbols:
			self.fetch_data_from_network(industry=industry, st_symbol=st_symbol, cur_data_only=cur_data_only)

	def fetch_airport_all_from_network(self, cur_data_only=False):
		symbols = []
		symbols.append('SH600009') # 上海机场
		symbols.append('SH600004') # 白云机场
		symbols.append('SZ000089') # 深圳机场
		symbols.append('SH600897') # 厦门空港
		
		industry = Cons.INDUSTRY_AIRPORT_ALL
		for st_symbol in symbols:
			self.fetch_data_from_network(industry=industry, st_symbol=st_symbol, cur_data_only=cur_data_only)
		
	# 其它
	def fetch_others_data_from_network(self, cur_data_only=False):
		symbols = []
		symbols.append('SH600298') # 安琪酵母
		symbols.append('SH601238') # 广汽集团

		industry = Cons.INDUSTRY_UNKNOWN
		for st_symbol in symbols:
			self.fetch_data_from_network(industry=industry, st_symbol=st_symbol, cur_data_only=cur_data_only)

	# ST
	def fetch_ST_data_from_network(self, cur_data_only=False):
		symbols = []
		symbols.append('SZ000972') # *ST中基

		industry = Cons.INDUSTRY_ST_ALL
		for st_symbol in symbols:
			self.fetch_data_from_network(industry=industry, st_symbol=st_symbol, cur_data_only=cur_data_only)
