# -*- coding: utf-8 -*-

import os
import shutil

class FileUtil(object):
	def __init__(self, basedir=None):
		self.basedir = basedir

	def cd(self, dpath):
		if self.basedir:
			self.basedir = '%s/%s' % (self.basedir, dpath)
		else:
			self.basedir = dpath

	def get_abs_path(self, fpath):
		if self.basedir is not None:
			fpath = '%s/%s' % (self.basedir, fpath)
		abs_path = os.path.join(os.getcwd(), fpath)
		return abs_path

	def is_file_exists(self, fpath):
		abs_path = self.get_abs_path(fpath=fpath)
		return os.path.exists(abs_path)

	def is_dir_exists(self, dpath):
		abs_path = self.get_abs_path(fpath=dpath)
		return os.path.exists(abs_path)

	def is_file(self, fpath):
		abs_path = self.get_abs_path(fpath=fpath)
		return os.path.isfile(abs_path)

	def is_dir(self, dpath):
		abs_path = self.get_abs_path(fpath=dpath)
		return os.path.isdir(abs_path)

	def create_dir(self, dpath, force=False):
		if self.is_dir_exists(dpath):
			if not self.is_dir(dpath):
				if force:
					self.rm_file(dpath)
					abs_path = self.get_abs_path(fpath=dpath)
					os.mkdir(abs_path)
				else:
					return
			else:
				return;
		else:
			abs_path = self.get_abs_path(fpath=dpath)
			os.mkdir(abs_path)

	def read_from_file(self, fpath):
		abs_path = self.get_abs_path(fpath=fpath)
		with open(abs_path, 'r') as f:
			return f.read()

	def write_to_file(self, fpath, content):
		if not content:
			return
		else:
			abs_path = self.get_abs_path(fpath=fpath)
			with open(abs_path, 'w') as f:
				f.write(content)

	def rm_file(self, fpath):
		if self.is_file_exists(fpath) and self.is_file(fpath):
			abs_path = self.get_abs_path(fpath=fpath)
			os.remove(abs_path)

	def rm_dir(self, dpath):
		if self.is_dir_exists(dpath) and self.is_dir(dpath):
			abs_path = self.get_abs_path(fpath=dpath)
			shutil.rmtree(abs_path)
