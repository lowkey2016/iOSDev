#!/usr/bin/env python
# -*- coding: utf-8 -*-

import sys
import time
from managers.st_mgr import StMgr
from analyzers.anlz_mgr import AnlzMgr

if __name__ == "__main__":
	reload(sys)
	sys.setdefaultencoding('utf8')
	starttime = time.time()

	st_mgr = StMgr()

	# json_data = ResUtil.read_json('test_zcfzb.json')
	# zcfzb = json.loads(json_data, object_hook=ZCFZB.as_self)
	# print zcfzb.__dict__

	# json_data = ResUtil.read_json('test_gslrb.json')
	# gslrb = json.loads(json_data, object_hook=GSLRB.as_self)
	# print gslrb.__dict__

	# json_data = ResUtil.read_json('test_xjllb.json')
	# xjllb = json.loads(json_data, object_hook=XJLLB.as_self)
	# print xjllb.__dict__

	# json_data = ResUtil.read_json('test_fjsj.json')
	# fjsj = json.loads(json_data, object_hook=FJSJ.as_self)
	# print fjsj.__dict__

	draw_all = False
	
	# 家电行业
	# st_mgr.fetch_eletric_all_data_from_network(cur_data_only=False)
	if draw_all or False:
		AnlzMgr.draw_eletric_all()

	# 家电的厨电细分行业
	# st_mgr.fetch_eletric_kitchen_data_from_network(cur_data_only=False)
	if draw_all or False:
		AnlzMgr.draw_eletric_kitchen()

	# 酿酒的白酒细分行业
	# st_mgr.fetch_vintage_spirit_data_from_network(cur_data_only=False)
	if draw_all or False:
		AnlzMgr.draw_vintage_spirit()

	# 食品饮料的调味品细分行业
	# st_mgr.fetch_fooddrink_condiment_data_from_network(cur_data_only=False)
	if draw_all or False:
		AnlzMgr.draw_fooddrink_condiment()

	# 房地产行业
	# st_mgr.fetch_realestate_all_data_from_network(cur_data_only=False)
	if draw_all or False:
		AnlzMgr.draw_realestate_all()

	# 房地产的 PPP 细分行业
	# st_mgr.fetch_realestate_ppp_data_from_network(cur_data_only=False)
	if draw_all or True:
		AnlzMgr.draw_realestate_ppp()

	# 中药行业
	# st_mgr.fetch_cn_medicine_all_from_network(cur_data_only=False)
	if draw_all or False:
		AnlzMgr.draw_cn_medicine()

	# 机场行业
	# st_mgr.fetch_airport_all_from_network(cur_data_only=False)
	if draw_all or True:
		AnlzMgr.draw_airport_all()

	# 其它
	# st_mgr.fetch_others_data_from_network(cur_data_only=False)
	if draw_all or False:
		AnlzMgr.draw_others()
 
 	endtime = time.time()
 	duration = endtime - starttime
 	print "耗时: %s 秒" % duration
