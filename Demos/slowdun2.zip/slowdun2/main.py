#!/usr/bin/env python
# -*- coding: utf-8 -*-

import os
import sys

if __name__ == "__main__":
	reload(sys)
	sys.setdefaultencoding('utf8')
