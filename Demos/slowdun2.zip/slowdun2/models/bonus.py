# -*- coding: utf-8 -*-

### 分红送配
class BONUS(object):
    bonusimpdate = "" # 分红公告日期
    bonusyear = "" # 分红实施年度
    cur = "" # 货币单位
    bonusskratio = "" # 送股比例（10送X）
    tranaddskraio = "" # 转增股比例（10转增X）
    recorddate = "" # 股权登记日
    exrightdate = "" # 除权除息日
    taxcdividend = 0.0 # 税前红利（元）
    taxfdividendbh = 0.0 # 税前红利（美元）
    tranaddsklistdate = "" # 转增股上市日
    bonussklistdate = "" # 送股上市日
    tranaddskaccday = "" # 转增股到账日
    bonusskaccday = "" # 送股到账日
    summarize = "" # 简介，例如 10派10送3

    @staticmethod
    def as_self(d):
        obj = BONUS()
        obj.__dict__.update(d)
        return obj

    def __init__(self, **entries):
        self.__dict__.update(entries)
        keys = ['bonusimpdate', 'bonusyear', 'cur', 'bonusskratio', 'tranaddskraio', 'recorddate', 'exrightdate', 'tranaddsklistdate', 'bonussklistdate', 'tranaddskaccday', 'bonusskaccday', 'summarize']
        for k in self.__dict__.keys():
            if self.__dict__[k] is None:
                if k in keys:
                    self.__dict__[k] = ''
                else:
                    self.__dict__[k] = 0.0
