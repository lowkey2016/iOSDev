# -*- coding: utf-8 -*-

import json
from zcfzb import ZCFZB
from gslrb import GSLRB
from xjllb import XJLLB
from fjsj import FJSJ
from bonus import BONUS
from quote import QUOTE
from mix import MIX
from utils.util_file import FileUtil
import utils.util_cons as Cons

class Stock(object):
	def __init__(self, industry, symbol, name, year_from=0, year_to=9999):
		assert industry and len(industry) > 0
		assert symbol and len(symbol) > 0
		assert name and len(name) > 0

		self.industry = industry
		self.symbol = symbol
		self.name = name

		dpath = 'resources/db/%s/%s_%s' % (industry, symbol, name)
		fu = FileUtil(basedir=dpath)

		years_zcfzbs = []
		years_gslrbs = []
		years_xjllbs = []

		# 解析资产负债表
		fpath = 'zcfzb.json'
		if fu.is_file_exists(fpath):
			json_data = json.loads(fu.read_from_file(fpath=fpath))
		else:
			json_data = None
		if json_data is not None and type(json_data) == type({}) and json_data['name'] == name and json_data['list'] is not None:
			des_dics = {}
			json_list = json_data['list']
			for dic in json_list:
				reportdate = dic['reportdate'] # ex. 20161231
				year = reportdate[0:4]
				monthday = reportdate[4:]
				if monthday == '1231' and int(year) >= year_from and int(year) <= year_to:
					tmp = ZCFZB(**dic)
					des_dics[year] = tmp
					years_zcfzbs.append(year)
			self.zcfzbs = des_dics
			# print self.zcfzbs
			years_zcfzbs.sort()

		# 解析利润表
		fpath = 'gslrb.json'
		if fu.is_file_exists(fpath):
			json_data = json.loads(fu.read_from_file(fpath=fpath))
		else:
			json_data = None
		if json_data is not None and type(json_data) == type({}) and json_data['name'] == name and json_data['list'] is not None:
			des_dics = {}
			json_list = json_data['list']
			for dic in json_list:
				reportdate = dic['enddate'] # ex. 20161231
				year = reportdate[0:4]
				monthday = reportdate[4:]
				if monthday == '1231' and int(year) >= year_from and int(year) <= year_to:
					tmp = GSLRB(**dic)
					des_dics[year] = tmp
					years_gslrbs.append(year)
			self.gslrbs = des_dics
			# print self.gslrbs
			years_gslrbs.sort()

		# 解析现金流量表
		fpath = 'xjllb.json'
		if fu.is_file_exists(fpath):
			json_data = json.loads(fu.read_from_file(fpath=fpath))
		else:
			json_data = None
		if json_data is not None and type(json_data) == type({}) and json_data['name'] == name and json_data['list'] is not None:
			des_dics = {}
			json_list = json_data['list']
			for dic in json_list:
				reportdate = dic['enddate'] # ex. 20161231
				year = reportdate[0:4]
				monthday = reportdate[4:]
				if monthday == '1231' and int(year) >= year_from and int(year) <= year_to:
					tmp = XJLLB(**dic)
					des_dics[year] = tmp
					years_xjllbs.append(year)
			self.xjllbs = des_dics
			# print self.xjllbs
			years_xjllbs.sort()

		assert len(self.zcfzbs) == len(self.gslrbs)
		assert len(self.zcfzbs) == len(self.xjllbs)
		assert len(years_zcfzbs) == len(years_gslrbs)
		assert len(years_gslrbs) == len(years_xjllbs)
		assert len(years_zcfzbs[0]) == len(years_gslrbs[0])
		assert len(years_zcfzbs[0]) == len(years_xjllbs[0])
		assert len(years_zcfzbs[-1]) == len(years_gslrbs[-1])
		assert len(years_zcfzbs[-1]) == len(years_xjllbs[-1])
		# print years_zcfzbs
		# print years_gslrbs
		# print years_xjllbs
		self.years = years_zcfzbs

		# 解析附加数据
		fpath = 'fjsj.json'
		if fu.is_file_exists(fpath):
			json_data = json.loads(fu.read_from_file(fpath=fpath))
		else:
			json_data = None
		if json_data is not None and type(json_data) == type({}) and json_data['name'] == name and json_data['list'] is not None:
			des_dics = {}
			json_list = json_data['list']
			for dic in json_list:
				reportdate = dic['reportdate'] # ex. 20161231
				year = reportdate[0:4]
				monthday = reportdate[4:]
				if monthday == '1231' and int(year) >= year_from and int(year) <= year_to:
					tmp = FJSJ(**dic)
					des_dics[year] = tmp
			self.fjsjs = des_dics
		else:
			self.fjsjs = {}
		# print self.fjsjs

		# 解析分红送配数据
		fpath = 'bonus.json'
		if fu.is_file_exists(fpath):
			json_data = json.loads(fu.read_from_file(fpath=fpath))
		else:
			json_data = None
		if json_data is not None and type(json_data) == type({}) and json_data['list'] is not None:
			des_dics = {}
			json_list = json_data['list']
			for dic in json_list:
				bonusyear = dic['bonusyear'] # ex. 2016
				if int(bonusyear) >= year_from and int(bonusyear) <= year_to:
					tmp = BONUS(**dic)
					if bonusyear in des_dics:
						bnsarr = des_dics[bonusyear]
						if bnsarr is None:
							bnsarr = []
					else:
						bnsarr = []
					bnsarr.append(tmp)
					# 某一年可能多次分红，所以这里 values 是一个数组，包括该年度的所有分红记录
					des_dics[bonusyear] = bnsarr
				else:
					des_dics[bonusyear] = []
			self.bonuses = des_dics
		else:
			self.bonuses = {}
		# print self.bonuses

		# 解析最新数据
		fpath = 'quote.json'
		if fu.is_file_exists(fpath):
			json_data = json.loads(fu.read_from_file(fpath=fpath))
		else:
			json_data = None
		if json_data is not None and type(json_data) == type({}) and json_data[symbol] is not None:
			des_dics = {}
			dic = json_data[symbol]
			if symbol == dic['symbol']:
				tmp = QUOTE(**dic)
				self.quote = tmp
			else:
				self.quote = None
		# print self.quote

		# 解析混合数据
		self.mixs = {}
		for y in self.years:
			mix = MIX(year=y)
			y_lst = str(int(y) - 1)

			zb = self.zcfzbs[y]
			if self.zcfzbs.has_key(y_lst):
				zb_lst = self.zcfzbs[y_lst]
			else:
				zb_lst = None

			lb = self.gslrbs[y]
			if self.gslrbs.has_key(y_lst):
				lb_lst = self.gslrbs[y_lst]
			else:
				lb_lst = None

			xb = self.xjllbs[y]
			if self.xjllbs.has_key(y_lst):
				xb_lst = self.xjllbs[y_lst]
			else:
				xb_lst = None

			if self.fjsjs.has_key(y):
				fj = self.fjsjs[y]
			else:
				fj = None
			if self.fjsjs.has_key(y_lst):
				fj_lst = self.fjsjs[y_lst]
			else:
				fj_lst = None
			
			qu = self.quote
			
			# 股东利润 = 报告利润 A + 折扣、摊销与其它成本 B - 维持公司长期竞争地位的资本支出 C
			mix.shareprofit = lb.netprofit + xb.depamortot - xb.capitalexp

			# 当年的扣除经常性损益营业利润 / 去年的资本支出
			if xb_lst and xb_lst.capitalexp > 0:
				mix.curprof_div_lstcapexp = lb.rmlosgainperprofit / xb_lst.capitalexp
			else:
				mix.curprof_div_lstcapexp = 0

			# (当年扣除经常性损益营业利润 - 去年扣除经常性损益营业利润) / 去年的资本资本支出
			if lb_lst and xb_lst and xb_lst.capitalexp > 0:
				mix.profchg_div_lstcapexp = (lb.rmlosgainperprofit - lb_lst.rmlosgainperprofit) / xb_lst.capitalexp
			else:
				mix.profchg_div_lstcapexp = 0

			# (当年扣除经常性损益营业利润 - 去年扣除经常性损益营业利润) / (去年的股东权益 - 前年的股东权益)
			y_beflst = str(int(y_lst) - 1)
			if self.zcfzbs.has_key(y_beflst):
				zb_beflst = self.zcfzbs[y_beflst]
			else:
				zb_beflst = None
			if lb_lst and zb_lst and zb_beflst:
				lstrigchg = zb_lst.righaggr - zb_beflst.righaggr
				if lstrigchg > 0:
					mix.profchg_div_lstrigchg = (lb.rmlosgainperprofit - lb_lst.rmlosgainperprofit) / lstrigchg
				else:
					mix.profchg_div_lstrigchg = 0
			else:
				mix.profchg_div_lstrigchg = 0

			y_beflst2 = str(int(y_beflst) - 1)
			if self.zcfzbs.has_key(y_beflst2):
				zb_beflst2 = self.zcfzbs[y_beflst2]
			else:
				zb_beflst2 = None

			if self.gslrbs.has_key(y_beflst):
				lb_beflst = self.gslrbs[y_beflst]
			else:
				lb_beflst = None
			if self.gslrbs.has_key(y_beflst2):
				lb_beflst2 = self.gslrbs[y_beflst2]
			else:
				lb_beflst2 = None

			# 累计利润 / 投入的股东权益 = ( 税后净利润Y1 + 税后净利润Y1+1 + … + 税后净利润Y2 ) / ( 股东权益Y2 - 股东权益Y1 )，每 3 年一个周期
			if zb_lst and zb_beflst and zb_beflst2 and lb_lst and lb_beflst and lb_beflst2:
				if (zb.righaggr - zb_beflst2.righaggr) != 0:
					mix.profsum_div_righin_3y = (lb.netprofit + lb_beflst.netprofit + lb_beflst2.netprofit) / (zb.righaggr - zb_beflst2.righaggr)
				else:
					mix.profsum_div_righin_3y = 0
			else:
				mix.profsum_div_righin_3y = 0

			# 累计利润 / 留存利润 = ( 税后净利润Y1 + 税后净利润Y1+1 + … + 税后净利润Y2 ) / ( 留存利润Y2 - 留存利润Y1 )，每 3 年一个周期
			if zb_lst and zb_beflst and zb_beflst2 and lb_lst and lb_beflst and lb_beflst2:
				if (zb.reseandundiprof - zb_beflst2.reseandundiprof) != 0:
					mix.profsum_div_stayprof_3y = (lb.netprofit + lb_beflst.netprofit + lb_beflst2.netprofit) / (zb.reseandundiprof - zb_beflst2.reseandundiprof)
				else:
					mix.profsum_div_stayprof_3y = 0
			else:
				mix.profsum_div_stayprof_3y = 0

			# ROE 和 ROA
			if zb_lst:
				mix.roe_this = lb.netprofit / zb_lst.righaggr
				mix.roe_ave = lb.netprofit / (zb.righaggr + zb_lst.righaggr) * 2
				mix.roa_this = lb.netprofit / zb_lst.totasset
				mix.roa_ave = lb.netprofit / (zb.totasset + zb_lst.totasset) * 2
				mix.roe_sp_this = mix.shareprofit / zb_lst.righaggr
				mix.roe_sp_ave = mix.shareprofit / (zb.righaggr + zb_lst.righaggr) * 2
				mix.roa_sp_this = mix.shareprofit / zb_lst.totasset
				mix.roa_sp_ave = mix.shareprofit / (zb.totasset + zb_lst.totasset) * 2
			else:
				mix.roe_this = 0
				mix.roe_ave = 0
				mix.roa_this = 0
				mix.roa_ave = 0
				mix.roe_sp_this = 0
				mix.roe_sp_ave = 0
				mix.roa_sp_this = 0
				mix.roa_sp_ave = 0

			# ROIC
			if zb_lst:
				# NOPLAT = (营业利润 - 非经常性损益 - 超额现金收益 + 债主利润) * (1 - 税率)
				# 其中: 财务费用 = 债主利润（也就是利息支出）- 超额现金收益
				mix.noplat = (lb.perprofit - lb.unoftenlosgain + lb.finexpe) * (1 - lb.incotaxexpe / lb.totprofit)

				# 非主营业务的生产相关资产 = 生物相关资产 + 油气资产 + 和主营业务无关的无形资产 + 待摊费用合计 + 递延所得税资产
				unoperprodasset = zb_lst.prodasse + zb_lst.comasse + zb_lst.hydrasset + zb_lst.prepexpe + zb_lst.logprepexpe + zb_lst.defetaxasset
				if fj_lst:
					unoperprodasset += fj_lst.unoperintaasset

				# 年初的超额现金 = 年初的货币资金 + 本年度增加的预收款合计 / 12 - (本年度的经营活动现金流出 + 本年度的资本支出) / 12
			    # 非主营业务的生产相关资产 = 生物相关资产 + 油气资产 + 和主营业务无关的无形资产 + 待摊费用合计 + 递延所得税资产
				mix.freecurfds_lst = zb_lst.curfds + (zb.notespaya + zb.accopaya + zb.advapaym - zb_lst.notespaya - zb_lst.accopaya - zb_lst.advapaym) / 12 - (xb.bizcashoutf + xb.capitalexp) / 12
				mix.curfds_lst = zb_lst.curfds

			    # IC = 年初的 股东权益 + 融资性负债（也可以称之为债主权益） + 一年内到期的非流动负债（将其全部看成有息负债，IC 算多不算少） - 超额现金（不需要用于日常运营的现金及现金等价物） - 投资相关资产 - 非主营业务的生产相关资产 - 其它资产
				mix.ic = zb_lst.righaggr + zb_lst.finliabtot + zb_lst.duenoncliab - mix.freecurfds_lst - zb_lst.inveassetot - unoperprodasset - zb_lst.otherasettot

				# ROIC = NOPLAT / IC
				mix.roic = mix.noplat / mix.ic

				# ROIC_sp
				mix.roic_sp = (mix.noplat + xb.depamortot - xb.capitalexp) / mix.ic
			else:
				mix.noplat = 0
				mix.ic = 0
				mix.freecurfds_lst = 0
				mix.curfds_lst = 0
				mix.roic = 0
				mix.roic_sp = 0

			if zb_lst:
				# 存货周转率 = 营业成本 / 存货平均余额，其中：存货平均余额 = (期初存货总额 + 期末存货总额) / 2
				mix.inve_torate = lb.bizcost / ((zb.inve + zb_lst.inve) / 2)
				# 存货周转天数 = 360 / 存货周转率
				if mix.inve_torate:
					mix.inve_todays = 360.0 / mix.inve_torate
				else:
					mix.inve_todays = 0.0

				# 应收账款周转率 = 营业收入 / 平均应收账款，其中：平均应收账款 = (期初应收账款总额 + 期末应收账款总额) / 2
				if zb.accorece + zb_lst.accorece != 0:
					mix.accorece_torate = lb.bizinco / ((zb.accorece + zb_lst.accorece) / 2)
				else:
					mix.accorece_torate = 0.0
				# 应收账款周转天数
				if mix.accorece_torate:
					mix.accorece_todays = 360.0 / mix.accorece_torate
				else:
					mix.accorece_todays = 0.0

				# 应付账款周转率 = 营业成本 / 应付账款平均余额，其中：应付账款平均余额 = (期初应付账款总额 + 期末应付账款总额) / 2
				mix.accopaya_torate = lb.bizcost / ((zb.accopaya + zb_lst.accopaya) / 2)
				# 应付账款周转天数
				if mix.accopaya_torate:
					mix.accopaya_todays = 360.0 / mix.accopaya_torate
				else:
					mix.accopaya_todays = 0.0

				# 资金周转周期 = 存货周转天数 + 应收账款周转天数 - 应付账款周转天数
				mix.turnoverdays = mix.inve_todays + mix.accorece_todays - mix.accopaya_todays
			else:
				mix.inve_torate = 0.0
				mix.inve_todays = 0.0
				mix.accorece_torate = 0.0
				mix.accorece_todays = 0.0
				mix.accopaya_torate = 0.0
				mix.accopaya_todays = 0.0
				mix.turnoverdays = 0.0

			self.mixs[y] = mix
		# print self.mixs
