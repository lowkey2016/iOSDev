# -*- coding: utf-8 -*-

import json
from zcfzb import ZCFZB
from gslrb import GSLRB
from xjllb import XJLLB
from fjsj import FJSJ
from quote import QUOTE
from utils.util_file import FileUtil
import utils.util_cons as Cons

class Stock(object):
	def __init__(self, industry, symbol, name, year_from=0, year_to=9999):
		assert industry and len(industry) > 0
		assert symbol and len(symbol) > 0
		assert name and len(name) > 0

		self.industry = industry
		self.symbol = symbol
		self.name = name

		dpath = 'resources/db/%s/%s_%s' % (industry, symbol, name)
		fu = FileUtil(basedir=dpath)
		
		# 解析资产负债表
		fpath = 'zcfzb.json'
		if fu.is_file_exists(fpath):
			json_data = json.loads(fu.read_from_file(fpath=fpath))
		else:
			json_data = None
		if json_data is not None and type(json_data) == type({}) and json_data['name'] == name and json_data['list'] is not None:
			des_dics = {}
			json_list = json_data['list']
			for dic in json_list:
				reportdate = dic['reportdate'] # ex. 20161231
				year = reportdate[0:4]
				monthday = reportdate[4:]
				if monthday == '1231' and int(year) >= year_from and int(year) <= year_to:
					tmp = ZCFZB(**dic)
					des_dics[year] = tmp
			self.zcfzbs = des_dics
			# print self.zcfzbs

		# 解析利润表
		fpath = 'gslrb.json'
		if fu.is_file_exists(fpath):
			json_data = json.loads(fu.read_from_file(fpath=fpath))
		else:
			json_data = None
		if json_data is not None and type(json_data) == type({}) and json_data['name'] == name and json_data['list'] is not None:
			des_dics = {}
			json_list = json_data['list']
			for dic in json_list:
				reportdate = dic['enddate'] # ex. 20161231
				year = reportdate[0:4]
				monthday = reportdate[4:]
				if monthday == '1231' and int(year) >= year_from and int(year) <= year_to:
					tmp = GSLRB(**dic)
					des_dics[year] = tmp
			self.gslrbs = des_dics
			# print self.gslrbs

		# 解析现金流量表
		fpath = 'xjllb.json'
		if fu.is_file_exists(fpath):
			json_data = json.loads(fu.read_from_file(fpath=fpath))
		else:
			json_data = None
		if json_data is not None and type(json_data) == type({}) and json_data['name'] == name and json_data['list'] is not None:
			des_dics = {}
			json_list = json_data['list']
			for dic in json_list:
				reportdate = dic['enddate'] # ex. 20161231
				year = reportdate[0:4]
				monthday = reportdate[4:]
				if monthday == '1231' and int(year) >= year_from and int(year) <= year_to:
					tmp = XJLLB(**dic)
					des_dics[year] = tmp
			self.xjllbs = des_dics
			# print self.xjllbs

		# 解析附加数据
		fpath = 'fjsj.json'
		if fu.is_file_exists(fpath):
			json_data = json.loads(fu.read_from_file(fpath=fpath))
		else:
			json_data = None
		if json_data is not None and type(json_data) == type({}) and json_data['name'] == name and json_data['list'] is not None:
			des_dics = {}
			json_list = json_data['list']
			for dic in json_list:
				reportdate = dic['reportdate'] # ex. 20161231
				year = reportdate[0:4]
				monthday = reportdate[4:]
				if monthday == '1231' and int(year) >= year_from and int(year) <= year_to:
					tmp = FJSJ(**dic)
					des_dics[year] = tmp
			self.fjsjs = des_dics
		else:
			self.fjsjs = {}
			# print self.fjsjs

		# 解析最新数据
		fpath = 'quote.json'
		if fu.is_file_exists(fpath):
			json_data = json.loads(fu.read_from_file(fpath=fpath))
		else:
			json_data = None
		if json_data is not None and type(json_data) == type({}) and json_data[symbol] is not None:
			des_dics = {}
			dic = json_data[symbol]
			if symbol == dic['symbol']:
				tmp = QUOTE(**dic)
				self.quote = tmp
			else:
				self.quote = None
			# print self.quote
