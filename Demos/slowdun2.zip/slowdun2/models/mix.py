# -*- coding: utf-8 -*-

### 三表混合
class MIX(object):
    year = '' # 年份
    shareprofit = 0.0 # 股东利润 = 报告利润 A + 折扣、摊销与其它成本 B - 维持公司长期竞争地位的资本支出 C

    # 是否小投入大产出参数
    curprof_div_lstcapexp = 0.0 # 当年的扣除经常性损益营业利润 / 去年的资本支出
    profchg_div_lstcapexp = 0.0 # (当年扣除经常性损益营业利润 - 去年扣除经常性损益营业利润) / 去年的资本支出
    profchg_div_lstrigchg = 0.0 # (当年扣除经常性损益营业利润 - 去年扣除经常性损益营业利润) / (去年的股东权益 - 前年的股东权益)

    # 留存利润使用效率
    profsum_div_righin_3y = 0.0 # 累计利润 / 投入的股东权益 = ( 税后净利润Y1 + 税后净利润Y1+1 + … + 税后净利润Y2 ) / ( 股东权益Y2 - 股东权益Y1 )，每 3 年一个周期
    profsum_div_stayprof_3y = 0.0 # 累计利润 / 留存利润 = ( 税后净利润Y1 + 税后净利润Y1+1 + … + 税后净利润Y2 ) / ( 留存利润Y2 - 留存利润Y1 )，每 3 年一个周期

    # ROE 和 ROA
    roe_this = 0.0 # 本期 ROE = 净利润 / 上期净资产
    roe_ave = 0.0 # 加权平均净资产收益率 ROE = 净利润 / 平均净资产
    roa_this = 0.0 # 本期 ROA = 净利润 / 上期总资产
    roa_ave = 0.0 # 加权平均总资产收益率 ROA = 净利润 / 平均总资产
    roe_sp_this = 0.0 # 股东利润本期 ROE = 股东利润 / 上期净资产
    roe_sp_ave = 0.0 # 股东利润加权平均 ROE = 股东利润 / 平均净资产
    roa_sp_this = 0.0 # 股东利润本期 ROA = 股东利润 / 上期总资产
    roa_sp_ave = 0.0 # 股东利润加权平均 ROA = 股东利润 / 平均总资产

    # ROIC = NOPLAT / IC
    # NOPLAT = (主营业务税前净利润 = 营业利润 - 非经常性损益 - 超额现金收益 + 债主利润) * (1 - 税率)
    # IC = 年初的 股东权益 + 融资性负债（也可以称之为债主权益） + 一年内到期的非流动负债（将其全部看成有息负债，IC 算多不算少） - 超额现金（不需要用于日常运营的现金及现金等价物） - 投资相关资产 - 非主营业务的生产相关资产 - 其它资产
    # 其中：
    # 年初的超额现金 = 货币资金 + 增加的预收款合计 / 12 - (经营活动现金流出 + 资本支出) / 12
    # 非主营业务的生产相关资产 = 生物相关资产 + 油气资产 + 和主营业务无关的无形资产 + 待摊费用合计 + 递延所得税资产
    noplat = 0.0
    ic = 0.0
    freecurfds_lst = 0.0
    curfds_lst = 0.0
    roic = 0.0

    # NOPLAT_shareprofit = NOPLAT + 折扣、摊销与其它成本 - 维持公司长期竞争地位的资本支出
    # 股东利润 ROIC = NOPLAT_sp / IC
    roic_sp = 0.0

    @staticmethod
    def as_self(d):
        obj = MIX()
        obj.__dict__.update(d)
        return obj

    def __init__(self, **entries):
        self.__dict__.update(entries)

    def __init__(self, year):
        self.year = year
