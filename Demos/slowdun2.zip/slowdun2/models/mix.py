# -*- coding: utf-8 -*-

### 三表混合
class MIX(object):
    year = '' # 年份
    shareprofit = 0.0 # 股东利润 = 报告利润 A + 折扣、摊销与其它成本 B - 维持公司长期竞争地位的资本支出 C

    # 是否小投入大产出参数
    curprof_div_lstcapexp = 0.0 # 当年的扣除经常性损益营业利润 / 去年的资本支出
    profchg_div_lstcapexp = 0.0 # (当年扣除经常性损益营业利润 - 去年扣除经常性损益营业利润) / 去年的资本支出
    profchg_div_lstrigchg = 0.0 # (当年扣除经常性损益营业利润 - 去年扣除经常性损益营业利润) / (去年的股东权益 - 前年的股东权益)

    # 留存利润使用效率
    profsum_div_righin_3y = 0.0 # 累计利润 / 投入的股东权益 = ( 税后净利润Y1 + 税后净利润Y1+1 + … + 税后净利润Y2 ) / ( 股东权益Y2 - 股东权益Y1 )，每 3 年一个周期
    profsum_div_stayprof_3y = 0.0 # 累计利润 / 留存利润 = ( 税后净利润Y1 + 税后净利润Y1+1 + … + 税后净利润Y2 ) / ( 留存利润Y2 - 留存利润Y1 )，每 3 年一个周期

    @staticmethod
    def as_self(d):
        obj = MIX()
        obj.__dict__.update(d)
        return obj

    def __init__(self, **entries):
        self.__dict__.update(entries)

    def __init__(self, year):
        self.year = year
