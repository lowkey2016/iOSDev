#!/usr/bin/env python
# -*- coding: utf-8 -*-

import math

cash_in = 1000000
rate = 0.1
years = 10
grow_rate = 0.06

value = 0
for i in range(0, 10):
	tmp_cash_in = cash_in * math.pow((1 + grow_rate), i)
	den = math.pow((1 + rate), i)
	value += tmp_cash_in / den
print value
