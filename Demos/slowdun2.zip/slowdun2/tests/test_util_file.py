# -*- coding: utf-8 -*-

import sys
sys.path.append('../utils')
from util_file import FileUtil

if __name__ == "__main__":
	reload(sys)
	sys.setdefaultencoding('utf8')

	fu = FileUtil(basedir=None)

	dpath = 'temp'
	fu.create_dir(dpath=dpath, force=True)
	assert fu.is_dir_exists(dpath)

	content = 'File Util Testing...'
	fname = '123.txt'
	fpath = '%s/%s' % (dpath, fname)
	fu.write_to_file(fpath=fpath, content=content)
	assert fu.is_file_exists(fpath=fpath)
	assert fu.is_file(fpath=fpath)
	assert fu.read_from_file(fpath=fpath) == content

	# fu.rm_file(fpath)
	# assert not fu.is_file_exists(fpath)
	# fu.rm_dir(dpath)
	# assert not fu.is_dir_exists(dpath)

	dirname = 'sub'
	dpath = '%s/%s' % (dpath, dirname)
	fu.create_dir(dpath=dpath, force=True)
	fu.cd(dpath)

	content = 'File Util Tested.'
	fpath = '456.txt'
	fu.write_to_file(fpath=fpath, content=content)
	assert fu.read_from_file(fpath=fpath) == content
