# -*- coding: utf-8 -*-

import os
from models.stock import Stock
from utils.util_res import ResUtil
import utils.util_cons as Cons
from drawer_assets import AssetsDrawer
from drawer_liabs import LiabsDrawer
from drawer_profit import ProfitDrawer
from drawer_cash import CashDrawer
from drawer_cash_in import CashInDrawer
from drawer_fjsj import FJSJDrawer
from drawer_quote import QuoteDrawer
from drawer_group import GroupDrawer

class AnlzMgr(object):
	def __init__(self, stock):
		if stock is None:
			return
		self.stock = stock

		minyear = 0
		maxyear = 0
		for k in stock.zcfzbs.keys():
			k = int(k)
			if minyear > k:
				minyear = k
			if maxyear < k:
				maxyear = k
		self.min_report_year = minyear
		self.max_report_year = maxyear

		self.assetsDrawer = AssetsDrawer(stock=stock)
		self.liabsDrawer = LiabsDrawer(stock=stock)
		self.profitDrawer = ProfitDrawer(stock=stock)
		self.cashDrawer = CashDrawer(stock=stock)
		self.cashinDrawer = CashInDrawer(stock=stock)
		self.fjsjDrawer = FJSJDrawer(stock=stock)
		self.quoteDrawer = QuoteDrawer(stock=stock)

	def draw(self):
		self.assetsDrawer.draw()
		self.liabsDrawer.draw()
		self.profitDrawer.draw()
		self.cashDrawer.draw()
		self.cashinDrawer.draw()
		self.fjsjDrawer.draw()
		self.quoteDrawer.draw()

	@classmethod
	def draw_jiadian(self):
		group = []

		stk = Stock(symbol='SZ000651', name='格力电器', year_from = 2007)
		anlz_mgr = AnlzMgr(stock=stk)
		anlz_mgr.draw()
		group.append(stk)

		stk = Stock(symbol='SZ000333', name='美的集团', year_from = 2007)
		anlz_mgr = AnlzMgr(stock=stk)
		anlz_mgr.draw()
		group.append(stk)

		stk = Stock(symbol='SH600690', name='青岛海尔', year_from = 2007)
		anlz_mgr = AnlzMgr(stock=stk)
		anlz_mgr.draw()
		group.append(stk)

	@classmethod
	def draw_jiadian_chudians(self):
		group = []

		stk = Stock(symbol='SZ002032', name='苏泊尔', year_from = 2010)
		anlz_mgr = AnlzMgr(stock=stk)
		anlz_mgr.draw()
		group.append(stk)

		stk = Stock(symbol='SZ002035', name='华帝股份', year_from = 2010)
		anlz_mgr = AnlzMgr(stock=stk)
		anlz_mgr.draw()
		group.append(stk)

		stk = Stock(symbol='SZ002242', name='九阳股份', year_from = 2010)
		anlz_mgr = AnlzMgr(stock=stk)
		anlz_mgr.draw()
		group.append(stk)

		stk = Stock(symbol='SZ002403', name='爱仕达', year_from = 2010)
		anlz_mgr = AnlzMgr(stock=stk)
		anlz_mgr.draw()
		group.append(stk)

		stk = Stock(symbol='SZ002508', name='老板电器', year_from = 2010)
		anlz_mgr = AnlzMgr(stock=stk)
		anlz_mgr.draw()
		group.append(stk)
		target = stk

		stk = Stock(symbol='SZ002543', name='万和电气', year_from = 2010)
		anlz_mgr = AnlzMgr(stock=stk)
		anlz_mgr.draw()
		group.append(stk)

		stk = Stock(symbol='SZ002677', name='浙江美大', year_from = 2010)
		anlz_mgr = AnlzMgr(stock=stk)
		anlz_mgr.draw()
		group.append(stk)

		gdrawer = GroupDrawer(industry=Cons.INDUSTRY_ELETRIC_KITCHEN, stocks_group=group, target=target)
		gdrawer.draw()

	@classmethod
	def draw_niangjiu_baijiu(self):
		group = []

		year_from = 2008

		stk = Stock(symbol='SH600519', name='贵州茅台', year_from = year_from)
		anlz_mgr = AnlzMgr(stock=stk)
		anlz_mgr.draw()
		group.append(stk)
		target = stk

		stk = Stock(symbol='SZ000858', name='五粮液', year_from = year_from)
		anlz_mgr = AnlzMgr(stock=stk)
		anlz_mgr.draw()
		group.append(stk)

		stk = Stock(symbol='SZ000568', name='泸州老窖', year_from = year_from)
		anlz_mgr = AnlzMgr(stock=stk)
		anlz_mgr.draw()
		group.append(stk)

		stk = Stock(symbol='SZ002304', name='洋河股份', year_from = year_from)
		anlz_mgr = AnlzMgr(stock=stk)
		anlz_mgr.draw()
		group.append(stk)

		stk = Stock(symbol='SH600702', name='沱牌舍得', year_from = year_from)
		anlz_mgr = AnlzMgr(stock=stk)
		anlz_mgr.draw()
		group.append(stk)

		stk = Stock(symbol='SZ000799', name='酒鬼酒', year_from = year_from)
		anlz_mgr = AnlzMgr(stock=stk)
		anlz_mgr.draw()
		group.append(stk)

		stk = Stock(symbol='SH603369', name='今世缘', year_from = year_from)
		anlz_mgr = AnlzMgr(stock=stk)
		anlz_mgr.draw()
		group.append(stk)

		stk = Stock(symbol='SZ000596', name='古井贡酒', year_from = year_from)
		anlz_mgr = AnlzMgr(stock=stk)
		anlz_mgr.draw()
		group.append(stk)

		stk = Stock(symbol='SH603589', name='口子窖', year_from = year_from)
		anlz_mgr = AnlzMgr(stock=stk)
		anlz_mgr.draw()
		group.append(stk)

		stk = Stock(symbol='SH600199', name='金种子酒', year_from = year_from)
		anlz_mgr = AnlzMgr(stock=stk)
		anlz_mgr.draw()
		group.append(stk)

		stk = Stock(symbol='SH603198', name='迎驾贡酒', year_from = year_from)
		anlz_mgr = AnlzMgr(stock=stk)
		anlz_mgr.draw()
		group.append(stk)

		stk = Stock(symbol='SH603919', name='金徽酒', year_from = year_from)
		anlz_mgr = AnlzMgr(stock=stk)
		anlz_mgr.draw()
		group.append(stk)

		stk = Stock(symbol='SH600197', name='伊力特', year_from = year_from)
		anlz_mgr = AnlzMgr(stock=stk)
		anlz_mgr.draw()
		group.append(stk)

		gdrawer = GroupDrawer(industry=Cons.INDUSTRY_VINTAGE_SPIRIT, stocks_group=group, target=target)
		gdrawer.draw()

	@classmethod
	def draw_fooddrink_condiment(self):
		group = []

		stk = Stock(symbol='SH603288', name='海天味业', year_from = 2009)
		anlz_mgr = AnlzMgr(stock=stk)
		anlz_mgr.draw()
		group.append(stk)
		target = stk

		# stk = Stock(symbol='SH603288', name='安记食品', year_from = 2007)
		# anlz_mgr = AnlzMgr(stock=stk)
		# anlz_mgr.draw()
		# group.append(stk)

		stk = Stock(symbol='SZ002650', name='加加食品', year_from = 2007)
		anlz_mgr = AnlzMgr(stock=stk)
		anlz_mgr.draw()
		group.append(stk)

		stk = Stock(symbol='SH603027', name='千禾味业', year_from = 2007)
		anlz_mgr = AnlzMgr(stock=stk)
		anlz_mgr.draw()
		group.append(stk)

		stk = Stock(symbol='SH600872', name='中炬高新', year_from = 2007)
		anlz_mgr = AnlzMgr(stock=stk)
		anlz_mgr.draw()
		group.append(stk)

		stk = Stock(symbol='SH600305', name='恒顺醋业', year_from = 2007)
		anlz_mgr = AnlzMgr(stock=stk)
		anlz_mgr.draw()
		group.append(stk)

		gdrawer = GroupDrawer(industry=Cons.INDUSTRY_FOODDRINK_CONDIMENT, stocks_group=group, target=target)
		gdrawer.draw()

	@classmethod
	def draw_fangdichan_ppp(self):
		group = []
		
		stk = Stock(symbol='SH600340', name='华夏幸福', year_from = 2011)
		anlz_mgr = AnlzMgr(stock=stk)
		anlz_mgr.draw()
		group.append(stk)

	@classmethod
	def draw_others(self):
		group = []
		
		stk = Stock(symbol='SH600298', name='安琪酵母', year_from = 2007)
		anlz_mgr = AnlzMgr(stock=stk)
		anlz_mgr.draw()
		group.append(stk)
