# -*- coding: utf-8 -*-

import os
from models.stock import Stock
import utils.util_cons as Cons
from drawer_assets import AssetsDrawer
from drawer_liabs import LiabsDrawer
from drawer_profit import ProfitDrawer
from drawer_cash import CashDrawer
from drawer_cash_in import CashInDrawer
from drawer_fjsj import FJSJDrawer
from drawer_quote import QuoteDrawer
from drawer_group import GroupDrawer

class AnlzMgr(object):
	def __init__(self, stock):
		if stock is None:
			return
		self.stock = stock

		minyear = 0
		maxyear = 0
		for k in stock.zcfzbs.keys():
			k = int(k)
			if minyear > k:
				minyear = k
			if maxyear < k:
				maxyear = k
		self.min_report_year = minyear
		self.max_report_year = maxyear

		self.assetsDrawer = AssetsDrawer(stock=stock)
		self.liabsDrawer = LiabsDrawer(stock=stock)
		self.profitDrawer = ProfitDrawer(stock=stock)
		self.cashDrawer = CashDrawer(stock=stock)
		self.cashinDrawer = CashInDrawer(stock=stock)
		self.fjsjDrawer = FJSJDrawer(stock=stock)
		self.quoteDrawer = QuoteDrawer(stock=stock)

	def draw(self):
		self.assetsDrawer.draw()
		self.liabsDrawer.draw()
		self.profitDrawer.draw()
		self.cashDrawer.draw()
		self.cashinDrawer.draw()
		self.fjsjDrawer.draw()
		self.quoteDrawer.draw()

	# 家电行业
	@classmethod
	def draw_eletric_all(self):
		group = []
		target = None
		industry = Cons.INDUSTRY_ELETRIC_ALL
		year_from = 2007
		tmparr = [
		{'symbol':'SZ000651', 'name':'格力电器', 'year_from':year_from},
		{'symbol':'SZ000333', 'name':'美的集团', 'year_from':year_from},
		{'symbol':'SH600690', 'name':'青岛海尔', 'year_from':year_from}
		]
		for dic in tmparr:
			stk = Stock(industry=industry, symbol=dic['symbol'], name=dic['name'], year_from=dic['year_from'])
			anlz_mgr = AnlzMgr(stock=stk)
			anlz_mgr.draw()
			group.append(stk)
			if stk.name == '格力电器':
				target = stk
		gdrawer = GroupDrawer(industry=industry, stocks_group=group, target=target)
		gdrawer.draw()

	# 家电的厨电细分行业
	@classmethod
	def draw_eletric_kitchen(self):
		group = []
		target = None
		industry = Cons.INDUSTRY_ELETRIC_KITCHEN
		year_from = 2010
		tmparr = [
		{'symbol':'SZ002508', 'name':'老板电器', 'year_from':year_from},
		{'symbol':'SZ002032', 'name':'苏泊尔', 'year_from':year_from},
		{'symbol':'SZ002035', 'name':'华帝股份', 'year_from':year_from},
		{'symbol':'SZ002242', 'name':'九阳股份', 'year_from':year_from},
		{'symbol':'SZ002403', 'name':'爱仕达', 'year_from':year_from},
		{'symbol':'SZ002543', 'name':'万和电气', 'year_from':year_from},
		{'symbol':'SZ002677', 'name':'浙江美大', 'year_from':year_from}
		]
		for dic in tmparr:
			stk = Stock(industry=industry, symbol=dic['symbol'], name=dic['name'], year_from=dic['year_from'])
			anlz_mgr = AnlzMgr(stock=stk)
			anlz_mgr.draw()
			group.append(stk)
			if stk.name == '老板电器':
				target = stk
		gdrawer = GroupDrawer(industry=industry, stocks_group=group, target=target)
		gdrawer.draw()

	# 酿酒的白酒细分行业
	@classmethod
	def draw_vintage_spirit(self):
		group = []
		target = None
		industry = Cons.INDUSTRY_VINTAGE_SPIRIT
		year_from = 2007
		tmparr = [
		{'symbol':'SH600519', 'name':'贵州茅台', 'year_from':year_from},
		{'symbol':'SZ000858', 'name':'五粮液', 'year_from':year_from},
		{'symbol':'SZ000568', 'name':'泸州老窖', 'year_from':year_from},
		{'symbol':'SZ002304', 'name':'洋河股份', 'year_from':year_from},
		{'symbol':'SH600702', 'name':'沱牌舍得', 'year_from':year_from},
		{'symbol':'SZ000799', 'name':'酒鬼酒', 'year_from':year_from},
		{'symbol':'SH603369', 'name':'今世缘', 'year_from':year_from},
		{'symbol':'SZ000596', 'name':'古井贡酒', 'year_from':year_from},
		{'symbol':'SH603589', 'name':'口子窖', 'year_from':year_from},
		{'symbol':'SH600199', 'name':'金种子酒', 'year_from':year_from},
		{'symbol':'SH603198', 'name':'迎驾贡酒', 'year_from':year_from},
		{'symbol':'SH603919', 'name':'金徽酒', 'year_from':year_from},
		{'symbol':'SH600197', 'name':'伊力特', 'year_from':year_from}
		]
		for dic in tmparr:
			stk = Stock(industry=industry, symbol=dic['symbol'], name=dic['name'], year_from=dic['year_from'])
			anlz_mgr = AnlzMgr(stock=stk)
			anlz_mgr.draw()
			group.append(stk)
			if stk.name == '贵州茅台':
				target = stk
		gdrawer = GroupDrawer(industry=industry, stocks_group=group, target=target)
		gdrawer.draw()

	# 食品饮料的调味品细分行业
	@classmethod
	def draw_fooddrink_condiment(self):
		group = []
		target = None
		industry = Cons.INDUSTRY_FOODDRINK_CONDIMENT
		year_from = 2007
		tmparr = [
		{'symbol':'SH603288', 'name':'海天味业', 'year_from':year_from},
		# {'symbol':'SH603288', 'name':'安记食品', 'year_from':year_from},
		{'symbol':'SZ002650', 'name':'加加食品', 'year_from':year_from},
		{'symbol':'SH603027', 'name':'千禾味业', 'year_from':year_from},
		{'symbol':'SH600872', 'name':'中炬高新', 'year_from':year_from},
		{'symbol':'SH600305', 'name':'恒顺醋业', 'year_from':year_from},
		]
		for dic in tmparr:
			stk = Stock(industry=industry, symbol=dic['symbol'], name=dic['name'], year_from=dic['year_from'])
			anlz_mgr = AnlzMgr(stock=stk)
			anlz_mgr.draw()
			group.append(stk)
			if stk.name == '海天味业':
				target = stk
		gdrawer = GroupDrawer(industry=industry, stocks_group=group, target=target)
		gdrawer.draw()

	# 房地产行业
	@classmethod
	def draw_realestate_all(self):
		group = []
		target = None
		industry = Cons.INDUSTRY_REALESTATE_ALL
		year_from = 2007
		tmparr = [
		{'symbol':'SZ000002', 'name':'万科A', 'year_from':year_from},
		{'symbol':'SH600048', 'name':'保利地产', 'year_from':year_from}
		]
		for dic in tmparr:
			stk = Stock(industry=industry, symbol=dic['symbol'], name=dic['name'], year_from=dic['year_from'])
			anlz_mgr = AnlzMgr(stock=stk)
			anlz_mgr.draw()
			group.append(stk)
			if stk.name == '万科A':
				target = stk
		gdrawer = GroupDrawer(industry=industry, stocks_group=group, target=target)
		gdrawer.draw()

	# 房地产的 PPP 细分行业
	@classmethod
	def draw_realestate_ppp(self):
		group = []
		target = None
		industry = Cons.INDUSTRY_REALESTATE_PPP
		year_from = 2011
		tmparr = [
		{'symbol':'SH600340', 'name':'华夏幸福', 'year_from':year_from},
		{'symbol':'SZ002146', 'name':'荣盛发展', 'year_from':year_from}
		]
		for dic in tmparr:
			stk = Stock(industry=industry, symbol=dic['symbol'], name=dic['name'], year_from=dic['year_from'])
			anlz_mgr = AnlzMgr(stock=stk)
			anlz_mgr.draw()
			group.append(stk)
			if stk.name == '华夏幸福':
				target = stk
		gdrawer = GroupDrawer(industry=industry, stocks_group=group, target=target)
		gdrawer.draw()

	# 中药行业
	@classmethod
	def draw_cn_medicine(self):
		group = []
		target = None
		industry = Cons.INDUSTRY_CN_MEDICINE_ALL
		year_from = 2011
		tmparr = [
		{'symbol':'SZ000423', 'name':'东阿阿胶', 'year_from':year_from}
		]
		for dic in tmparr:
			stk = Stock(industry=industry, symbol=dic['symbol'], name=dic['name'], year_from=dic['year_from'])
			anlz_mgr = AnlzMgr(stock=stk)
			anlz_mgr.draw()
			group.append(stk)
			if stk.name == '东阿阿胶':
				target = stk
		gdrawer = GroupDrawer(industry=industry, stocks_group=group, target=target)
		gdrawer.draw()

	# 其它
	@classmethod
	def draw_others(self):
		industry = Cons.INDUSTRY_UNKNOWN
		year_from = 2007
		tmparr = [
		{'symbol':'SH600298', 'name':'安琪酵母', 'year_from':year_from},
		{'symbol':'SH601238', 'name':'广汽集团', 'year_from':year_from}
		]
		for dic in tmparr:
			stk = Stock(industry=industry, symbol=dic['symbol'], name=dic['name'], year_from=dic['year_from'])
			anlz_mgr = AnlzMgr(stock=stk)
			anlz_mgr.draw()
